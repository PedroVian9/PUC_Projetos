#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    try
    {
        objetoVetor = new Ordenar (ui->entradaQuant->text().toInt());
        ui->saidaOriginal->setText(objetoVetor->acessarVetor());
    }
    catch (QString& erro)
    {
        QMessageBox::critical(this, "Erro ", erro);
    }
}


void MainWindow::on_botaoOrdenar_clicked()
{
    try
    {
        if (ui->inputRegra->currentText() == "Crescente")
        {
            objetoVetor->OrdenarCrescente();
        }
        else
        {
            objetoVetor->OrdenarDecrescente();
        }
        ui->saidaOrdenado->setText(objetoVetor->acessarVetor());
    }
    catch (QString &erro)
    {
        QMessageBox::critical(this, "Erro ", erro);
    }
}

