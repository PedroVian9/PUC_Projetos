#include "fila.h"
#include <iostream>
#include <QString>


Fila::Fila(int tamanho):
   tamanho(0), array(0), inicio(-1), fim(-1), quantidadeDeElementos(0)
{
    if(tamanho <= 0){
           throw QString("Tamanho Inválido"); //grita
       }
       try{ //monitora
       array = new int[tamanho]; //recebe tamanho
       this->tamanho = tamanho;
       }
       catch (std::bad_alloc & erro) { // resolve
           throw QString("Má locação de memória");
       }
}

bool Fila::estaVazia() const
{
    return(quantidadeDeElementos == 0);
}

bool Fila::estaCheia() const
{
    return(quantidadeDeElementos == tamanho);
}

int Fila::acessar() const
{
    if(estaVazia()) throw QString("A FILA ESTÁ VAZIA");
    return array[inicio];
}

void Fila::inserir(int elemento)
{
    if(estaCheia())
    {
        throw  QString("Impossível alocar, array cheio");
    }
    quantidadeDeElementos++;
    if(estaVazia())
    {
        inicio = fim = 0;
        array[fim] = elemento;
        return;
        fim++;
    }
    else{
        fim++;
        array[fim] = elemento;
    }


}

int Fila::retirar()
{

}
