/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *entradaQuant;
    QTextEdit *saidaOriginal;
    QTextEdit *saidaOrdenado;
    QPushButton *pushButton;
    QPushButton *botaoOrdenar;
    QComboBox *inputRegra;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(724, 303);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(140, 0, 511, 71));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(140, 70, 271, 21));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(140, 100, 171, 21));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(140, 170, 101, 21));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(140, 200, 171, 31));
        entradaQuant = new QLineEdit(centralwidget);
        entradaQuant->setObjectName("entradaQuant");
        entradaQuant->setGeometry(QRect(410, 70, 91, 22));
        saidaOriginal = new QTextEdit(centralwidget);
        saidaOriginal->setObjectName("saidaOriginal");
        saidaOriginal->setGeometry(QRect(300, 100, 311, 21));
        saidaOriginal->setReadOnly(true);
        saidaOrdenado = new QTextEdit(centralwidget);
        saidaOrdenado->setObjectName("saidaOrdenado");
        saidaOrdenado->setGeometry(QRect(300, 200, 311, 21));
        saidaOrdenado->setReadOnly(true);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(530, 70, 80, 23));
        botaoOrdenar = new QPushButton(centralwidget);
        botaoOrdenar->setObjectName("botaoOrdenar");
        botaoOrdenar->setGeometry(QRect(530, 170, 80, 23));
        inputRegra = new QComboBox(centralwidget);
        inputRegra->addItem(QString());
        inputRegra->addItem(QString());
        inputRegra->setObjectName("inputRegra");
        inputRegra->setGeometry(QRect(230, 170, 131, 23));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 724, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:700;\">SISTEMA ORDENA\303\207\303\203O USANDO FILA</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">QUANTIDADE DE ELEMENTOS: </span></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">ARRAY ORIGINAL: </span></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">CRIT\303\211RIO: </span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt;\">ARRAY ORDENAR: </span></p><p><span style=\" font-size:14pt;\"><br/></span></p></body></html>", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "CRIAR", nullptr));
        botaoOrdenar->setText(QCoreApplication::translate("MainWindow", "ORDENAR", nullptr));
        inputRegra->setItemText(0, QCoreApplication::translate("MainWindow", "CRESCENTE", nullptr));
        inputRegra->setItemText(1, QCoreApplication::translate("MainWindow", "DECRESCENTE", nullptr));

    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
