#ifndef FILA_H
#define FILA_H


class Fila
{
private:
    int tamanho;
    int *array;
    int inicio;
    int fim;
    int quantidadeDeElementos;
public:
    Fila(int tamanho);
    ~Fila();
    bool estaVazia()const;
    bool estaCheia()const;
    int acessar()const;
    void inserir(int elemento);
    int retirar();
};

#endif // FILA_H
