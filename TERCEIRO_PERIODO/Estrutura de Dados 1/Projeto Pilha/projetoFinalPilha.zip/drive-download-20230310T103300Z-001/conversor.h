#ifndef CONVERSOR_H
#define CONVERSOR_H
#include <QString>

class Conversor
{
private:
    int valor;
    int base;
public:
    Conversor();
    int getValor() const;
    void setValor(int newValor);
    int getBase() const;
    void setBase(int newBase);

    Conversor(int valor, int base);
    QString decimal()const;
};

#endif // CONVERSOR_H
