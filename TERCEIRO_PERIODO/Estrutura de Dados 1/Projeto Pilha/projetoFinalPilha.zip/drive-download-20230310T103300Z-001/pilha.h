#ifndef PILHA_H
#define PILHA_H


class Pilha
{
private:
    int tamanhoDaPilha;
    int topoDaPilha;
    int *ponteiroPilha;
public:
    Pilha(int tamanhoDaPilha);
    ~Pilha(){if(ponteiroPilha!=0)delete[]ponteiroPilha;}
    void empilha(int resto);
    int retira();
    bool pilhaCheia()const{
        return (topoDaPilha == tamanhoDaPilha - 1);
    };
    bool pilhaVazia()const{
        return (topoDaPilha ==- 1);
    };

};
#endif // PILHA_H
