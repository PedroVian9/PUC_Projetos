#include "conversor.h"
#include <pilha.h>
int Conversor::getValor() const
{
    return valor;
}

void Conversor::setValor(int newValor)
{
    valor = newValor;
}

int Conversor::getBase() const
{
    return base;
}

void Conversor::setBase(int newBase)
{
    base = newBase;
}

Conversor::Conversor(int valor, int base):
    valor(valor),
    base(base)
{

}
QString Conversor::decimal()const
{
    Pilha p(50);
    QString saida = "";
    QString str = "0123456789ABCDEF";
    int resto = 0;
    int aux = valor;

    while(aux != 0)
    {
        resto = aux%base;
        p.empilha(resto);
        aux /= base;
    }
    while(!p.pilhaVazia())
    {
        int pos = p.retira();
        saida += str[pos];
    }
    return saida;
}
