#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "conversor.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    int pos = ui->comboBox->currentIndex();
    int valor = ui->entrada->text().toInt();
    int base = 0;

    if (pos == 0) base = 2;
    if (pos == 1) base = 8;
    if (pos == 2) base = 16;

    Conversor convert(valor, base);
    QString dado = convert.decimal();
    ui->saida->setText(convert.decimal());
}

