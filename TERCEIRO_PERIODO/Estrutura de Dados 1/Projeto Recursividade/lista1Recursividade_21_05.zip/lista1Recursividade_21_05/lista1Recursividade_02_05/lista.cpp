#include "lista.h"

lista::lista()
{

}

QString lista::exercicio1Interativo(int n)
{
    if(n<=1)
    {
       throw QString ("Valor inválido, digite novamente.");
    }
       QString res="";
       for(int i=1; i<=n; i++)
       {
         res+=QString::number(i);
         if((i+1)<=n)
         {
           res+=", ";
         }
       }
       return res;
}

QString lista::exercicio1Recursivo(int n, int aux, QString saida)
{
    if(aux <= n){
            saida += QString::number(aux);
            if(aux < n){ saida += ", "; }
            return exercicio1Recursivo(n, aux+1, saida);
        }
        else return saida;
}

QString lista::exercicio2Interativo(int n)
{
    if(n<=1)
    {
       throw QString ("Valor inválido, digite novamente.");
    }
    QString res="";
    for(int i=1; i<=n; i++)
    {
        if(i % 2 == 0){
            res+=QString::number(i);
            if((i+1)<=n)
            {
              res+=", ";
            }
        }
    }
    return res;
}

QString lista::exercicio2Recursivo(int n, int aux, QString saida)
{
    if(aux <= n){
            if(aux%2==0){ saida+=QString::number(aux); }
            if(aux%2==0 & aux<n){ saida += ", "; }
            return exercicio2Recursivo(n, aux+1, saida);
        }
        else return saida;
}

QString lista::exercicio3Interativo(int n)
{
    if(n<=1)
    {
       throw QString ("Valor inválido, digite novamente.");
    }
    QString res="";
    for(int i=1; i<=n; i++)
    {
        if(i % 2 != 0){
            res+=QString::number(i);
            if((i+1)<=n)
            {
              res+=", ";
            }
        }
    }
    return res;
}

QString lista::exercicio3Recursivo(int n, int aux, QString saida)
{
    if(aux <= n){
            if(aux%2!=0){ saida+=QString::number(aux); }
            if(aux%2!=0 & aux<n){ saida += ", "; }
            return exercicio3Recursivo(n, aux+1, saida);
        }
        else return saida;
}

QString lista::exercicio4Interativo(int n)
{
    if(n<=1)
    {
       throw QString ("Valor inválido, digite novamente.");
    }
    QString res="";
    int soma = 0;
    for(int i = 1; i <= n; i++){
        soma = soma + i;
    }
    res = QString::number(soma);
    return res;
}

QString lista::exercicio4Recursivo(int n, int aux,int soma, QString saida)
{
    if(aux <= n){
           soma = soma+aux;
           return exercicio4Recursivo(n, aux+1, soma,  saida);
       }
       else{
           saida = QString::number(soma);
           return saida;
       }
}

QString lista::exercicio5Interativo()
{
    {
        QString res="";
        double pi = 0;
        double s = 1;
        double denom = 1;
        double soma = 0;
        for(int t = 1; t <= 51; t++)
        {
            soma = soma + ((1.0/std::pow(denom,3)) * s);
            denom = denom + 2;
            s = s * (-1);
        }
        pi = std::pow((soma*32),1.0/3.0);
       res = QString::number(pi);
       return res;
    }
}

QString lista::exercicio6Interativo()
{
    QString res="";
    double pi = 0;
       double s = 1;

       for(float i = 1.0; (4.0/i)>0.0001; i = i + 2.0)
       {
           pi = pi + (4.0/i) * s;
           s = s * (-1);
       }
       res = QString::number(pi);
       return res;
}
