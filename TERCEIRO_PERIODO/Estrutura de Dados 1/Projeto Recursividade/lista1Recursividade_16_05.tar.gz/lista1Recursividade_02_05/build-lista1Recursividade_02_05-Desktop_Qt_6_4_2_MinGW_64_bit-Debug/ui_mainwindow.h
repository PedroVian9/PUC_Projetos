/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_8;
    QTextEdit *textEditSaida;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QPushButton *pushButtonInterativo1;
    QPushButton *pushButtonRecursivo1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QPushButton *pushButtonInterativo2;
    QPushButton *pushButtonRecursivo2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QPushButton *pushButtonInterativo3;
    QPushButton *pushButtonRecursivo3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_5;
    QPushButton *pushButtonInterativo4;
    QPushButton *pushButtonRecursivo4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_6;
    QPushButton *pushButtonInterativo5;
    QPushButton *pushButtonRecursivo5;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_7;
    QPushButton *pushButtonInterativo6;
    QPushButton *pushButtonRecursivo6;
    QLabel *label_9;
    QLineEdit *lineEditEntrada;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(379, 404);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(240, 250, 131, 111));
        verticalLayout_4 = new QVBoxLayout(layoutWidget);
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName("label_8");

        verticalLayout_4->addWidget(label_8);

        textEditSaida = new QTextEdit(layoutWidget);
        textEditSaida->setObjectName("textEditSaida");
        textEditSaida->setReadOnly(true);

        verticalLayout_4->addWidget(textEditSaida);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(10, 10, 362, 244));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget1);
        label->setObjectName("label");

        verticalLayout_2->addWidget(label);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName("label_2");

        horizontalLayout->addWidget(label_2);

        pushButtonInterativo1 = new QPushButton(layoutWidget1);
        pushButtonInterativo1->setObjectName("pushButtonInterativo1");

        horizontalLayout->addWidget(pushButtonInterativo1);

        pushButtonRecursivo1 = new QPushButton(layoutWidget1);
        pushButtonRecursivo1->setObjectName("pushButtonRecursivo1");

        horizontalLayout->addWidget(pushButtonRecursivo1);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName("label_3");

        horizontalLayout_2->addWidget(label_3);

        pushButtonInterativo2 = new QPushButton(layoutWidget1);
        pushButtonInterativo2->setObjectName("pushButtonInterativo2");

        horizontalLayout_2->addWidget(pushButtonInterativo2);

        pushButtonRecursivo2 = new QPushButton(layoutWidget1);
        pushButtonRecursivo2->setObjectName("pushButtonRecursivo2");

        horizontalLayout_2->addWidget(pushButtonRecursivo2);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName("label_4");

        horizontalLayout_3->addWidget(label_4);

        pushButtonInterativo3 = new QPushButton(layoutWidget1);
        pushButtonInterativo3->setObjectName("pushButtonInterativo3");

        horizontalLayout_3->addWidget(pushButtonInterativo3);

        pushButtonRecursivo3 = new QPushButton(layoutWidget1);
        pushButtonRecursivo3->setObjectName("pushButtonRecursivo3");

        horizontalLayout_3->addWidget(pushButtonRecursivo3);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName("label_5");

        horizontalLayout_4->addWidget(label_5);

        pushButtonInterativo4 = new QPushButton(layoutWidget1);
        pushButtonInterativo4->setObjectName("pushButtonInterativo4");

        horizontalLayout_4->addWidget(pushButtonInterativo4);

        pushButtonRecursivo4 = new QPushButton(layoutWidget1);
        pushButtonRecursivo4->setObjectName("pushButtonRecursivo4");

        horizontalLayout_4->addWidget(pushButtonRecursivo4);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName("label_6");

        horizontalLayout_5->addWidget(label_6);

        pushButtonInterativo5 = new QPushButton(layoutWidget1);
        pushButtonInterativo5->setObjectName("pushButtonInterativo5");

        horizontalLayout_5->addWidget(pushButtonInterativo5);

        pushButtonRecursivo5 = new QPushButton(layoutWidget1);
        pushButtonRecursivo5->setObjectName("pushButtonRecursivo5");

        horizontalLayout_5->addWidget(pushButtonRecursivo5);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName("label_7");

        horizontalLayout_6->addWidget(label_7);

        pushButtonInterativo6 = new QPushButton(layoutWidget1);
        pushButtonInterativo6->setObjectName("pushButtonInterativo6");

        horizontalLayout_6->addWidget(pushButtonInterativo6);

        pushButtonRecursivo6 = new QPushButton(layoutWidget1);
        pushButtonRecursivo6->setObjectName("pushButtonRecursivo6");

        horizontalLayout_6->addWidget(pushButtonRecursivo6);


        verticalLayout->addLayout(horizontalLayout_6);


        verticalLayout_2->addLayout(verticalLayout);

        label_9 = new QLabel(centralwidget);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(10, 260, 129, 31));
        lineEditEntrada = new QLineEdit(centralwidget);
        lineEditEntrada->setObjectName("lineEditEntrada");
        lineEditEntrada->setGeometry(QRect(10, 290, 121, 71));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 379, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:700;\">RESPOSTA:</span></p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:700;\">LISTA 1 DE RECURSIVIDADE</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:700;\">EXERC\303\215CIO 1: </span></p></body></html>", nullptr));
        pushButtonInterativo1->setText(QCoreApplication::translate("MainWindow", "INTERATIVO 1", nullptr));
        pushButtonRecursivo1->setText(QCoreApplication::translate("MainWindow", "RECURSIVO 1", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:700;\">EXERC\303\215CIO 2: </span></p></body></html>", nullptr));
        pushButtonInterativo2->setText(QCoreApplication::translate("MainWindow", "INTERATIVO 2", nullptr));
        pushButtonRecursivo2->setText(QCoreApplication::translate("MainWindow", "RECURSIVO 2", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:700;\">EXERC\303\215CIO 3: </span></p></body></html>", nullptr));
        pushButtonInterativo3->setText(QCoreApplication::translate("MainWindow", "INTERATIVO 3", nullptr));
        pushButtonRecursivo3->setText(QCoreApplication::translate("MainWindow", "RECURSIVO 3", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:700;\">EXERC\303\215CIO 4: </span></p></body></html>", nullptr));
        pushButtonInterativo4->setText(QCoreApplication::translate("MainWindow", "INTERATIVO 4", nullptr));
        pushButtonRecursivo4->setText(QCoreApplication::translate("MainWindow", "RECURSIVO 4", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:700;\">EXERC\303\215CIO 5: </span></p></body></html>", nullptr));
        pushButtonInterativo5->setText(QCoreApplication::translate("MainWindow", "INTERATIVO 5", nullptr));
        pushButtonRecursivo5->setText(QCoreApplication::translate("MainWindow", "RECURSIVO 5", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:700;\">EXERC\303\215CIO 6: </span></p></body></html>", nullptr));
        pushButtonInterativo6->setText(QCoreApplication::translate("MainWindow", "INTERATIVO 6", nullptr));
        pushButtonRecursivo6->setText(QCoreApplication::translate("MainWindow", "RECURSIVO 6", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:700;\">ENTRADA:</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
