#ifndef LISTA_H
#define LISTA_H
#include <QString>
#include <cmath>
#include <iostream>

class lista
{
public:
    lista();

    QString exercicio1Interativo(int n);
    QString exercicio1Recursivo(int n, int aux, QString saida);

    QString exercicio2Interativo(int n);
    QString exercicio2Recursivo(int n, int aux, QString saida);

    QString exercicio3Interativo(int n);
    QString exercicio3Recursivo(int n, int aux, QString saida);

    QString exercicio4Interativo(int n);
    QString exercicio4Recursivo(int n, int aux, int soma, QString saida);

    QString exercicio5Interativo();
    QString exercicio5Recursivo(double pi, double s, double denom, double soma, int t, QString res);

    QString exercicio6Interativo();
    QString exercicio6Recursivo(double pi, double sinal, double impar, QString saida);
};

#endif // LISTA_H
