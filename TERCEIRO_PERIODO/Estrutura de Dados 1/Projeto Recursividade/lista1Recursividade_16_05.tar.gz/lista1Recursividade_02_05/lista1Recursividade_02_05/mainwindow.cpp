#include "mainwindow.h"
#include "lista.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

lista Exercicios;

void MainWindow::on_pushButtonInterativo1_clicked()
{
    QString resultado="";
    int valorDeEntrada=0;
    valorDeEntrada=ui->lineEditEntrada->text().toInt();
    if(valorDeEntrada<2)
    {
        QMessageBox::critical(this,"","Valor inválido");
        return;
    }
    resultado=Exercicios.exercicio1Interativo(valorDeEntrada);
    ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonInterativo2_clicked()
{
    QString resultado="";
    int valorDeEntrada=0;
    valorDeEntrada=ui->lineEditEntrada->text().toInt();
    if(valorDeEntrada<2) //numeros de 1 ate 1 ???
    {
        QMessageBox::critical(this,"","Valor inválido");
        return;
    }
    resultado=Exercicios.exercicio2Interativo(valorDeEntrada);
    ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonInterativo3_clicked()
{
    QString resultado="";
    int valorDeEntrada=0;
    valorDeEntrada=ui->lineEditEntrada->text().toInt();
    if(valorDeEntrada<2) //numeros de 1 ate 1 ???
    {
        QMessageBox::critical(this,"","Valor inválido");
        return;
    }
    resultado=Exercicios.exercicio3Interativo(valorDeEntrada);
    ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonInterativo4_clicked()
{
    QString resultado="";
    int valorDeEntrada=0;
    valorDeEntrada=ui->lineEditEntrada->text().toInt();
    if(valorDeEntrada<2) //numeros de 1 ate 1 ???
    {
        QMessageBox::critical(this,"","Valor inválido");
        return;
    }
    resultado=Exercicios.exercicio4Interativo(valorDeEntrada);
    ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonInterativo5_clicked()
{
    QString resultado="";
    resultado=Exercicios.exercicio5Interativo();
    ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonInterativo6_clicked()
{
    QString resultado="";
    resultado=Exercicios.exercicio6Interativo();
    ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonRecursivo1_clicked()
{
    QString resultado="";
    int valorDeEntrada=0;
    valorDeEntrada=ui->lineEditEntrada->text().toInt();
    if(valorDeEntrada<2)
    {
        QMessageBox::critical(this,"","Valor inválido");
        return;
    }
    resultado=Exercicios.exercicio1Recursivo(valorDeEntrada, 1, "");
    ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonRecursivo2_clicked()
{
    QString resultado="";
    QString saida="";
    int valorDeEntrada=0;
    valorDeEntrada=ui->lineEditEntrada->text().toInt();
    if(valorDeEntrada<2)
    {
        QMessageBox::critical(this,"","Valor inválido");
        return;
    }
        resultado=Exercicios.exercicio2Recursivo(valorDeEntrada, 1, "");
        ui->textEditSaida->setText(resultado);
}


void MainWindow::on_pushButtonRecursivo3_clicked()
{
    QString resultado="";
    QString saida="";
    int valorDeEntrada=0;
    valorDeEntrada=ui->lineEditEntrada->text().toInt();
    if(valorDeEntrada<2)
    {
        QMessageBox::critical(this,"","Valor inválido");
        return;
    }
        resultado=Exercicios.exercicio3Recursivo(valorDeEntrada, 1, "");
        ui->textEditSaida->setText(resultado);
}

void MainWindow::on_pushButtonRecursivo4_clicked()
{
    QString saida="";
        int n = ui->lineEditEntrada->text().toInt();
        if(n<=1){
            QMessageBox::information(this,"","VALOR INVÁLIDO, DIGITE UM VALOR POSITIVO MAIOR QUE 1");
            return;
        }
        saida = Exercicios.exercicio4Recursivo(n, 1, 0, "");
        ui->textEditSaida->setText(saida);
}


void MainWindow::on_pushButtonRecursivo5_clicked()
{
    QString saida="";
        saida = Exercicios.exercicio5Recursivo(0, 1, 1, 0, 0, "");
        ui->textEditSaida->setText(saida);
}

void MainWindow::on_pushButtonRecursivo6_clicked()
{
    QString saida="";
        saida = Exercicios.exercicio6Recursivo(0, 1, 1, "");
        ui->textEditSaida->setText(saida);
}

