#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <fstream>
#include <list>
#include <string>
#include <iterator>
#include <QFileDialog>
#include <QMainWindow>

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
       ui->lineEdit_matricula->hide();
       ui->pushButton_aluno->hide();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_buscar_clicked()
{
    // Abre a janela de diálogo para selecionar o arquivo
        QString filePath = QFileDialog::getOpenFileName(this, "Selecione o arquivo", "", "CSV ou TXT (*.csv *.txt)");

        // Verifica se o arquivo foi selecionado
        if (!filePath.isEmpty())
        {
            // Atualiza o QLineEdit com o caminho do arquivo selecionado
            ui->lineEdit_arquivo->setText(filePath);

            // Cria uma lista para armazenar os dados do arquivo
            list<string> dataList;

            // Abre o arquivo selecionado
            ifstream file(filePath.toStdString());

            // Verifica se o arquivo foi aberto com sucesso
            if (file.is_open())
            {
                string line;

                // Lê cada linha do arquivo
                while (getline(file, line))
                {
                    // Adiciona a linha à lista
                    dataList.push_back(line);
                }

                // Fecha o arquivo
                file.close();

                // Limpa a tabela
                ui->tableWidget_Exibir->clearContents();
                ui->tableWidget_Exibir->setRowCount(0);

                // Exibe os dados lidos na tabela
                int row = 0;
                for (const auto& data : dataList)
                {
                    ui->tableWidget_Exibir->insertRow(row);
                    QTableWidgetItem* item = new QTableWidgetItem(QString::fromStdString(data));
                    ui->tableWidget_Exibir->setItem(row, 0, item);
                    ++row;
                }
            }
            else
            {
                QMessageBox::critical(this, "Erro", "Não foi possível abrir o arquivo.");
            }
        }
        else
        {
            QMessageBox::information(this, "Informação", "Nenhum arquivo selecionado.");
        }
}

void MainWindow::on_pushButton_opcao_clicked()
{
    int aux = ui->comboBox_opcao->currentIndex();
        if(aux == 0){
            ui->lineEdit_matricula->hide();
            ui->pushButton_aluno->hide();
        }
        if(aux == 1){
            ui->lineEdit_matricula->hide();
            ui->pushButton_aluno->hide();
        }
        if(aux == 2){
            ui->lineEdit_matricula->hide();
            ui->pushButton_aluno->hide();
        }
        if(aux == 3){
            ui->lineEdit_matricula->show();
            ui->pushButton_aluno->show();
        }
}

void MainWindow::on_pushButton_filtro_clicked()
{

}

void MainWindow::on_pushButton_aluno_clicked()
{

}
