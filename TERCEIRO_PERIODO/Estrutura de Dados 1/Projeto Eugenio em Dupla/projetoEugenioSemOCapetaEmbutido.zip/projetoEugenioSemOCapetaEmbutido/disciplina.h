#ifndef DISCIPLINA_H
#define DISCIPLINA_H


class disciplina
{
public:
    disciplina();
};

#endif // DISCIPLINA_H
