#ifndef ALUNO_H
#define ALUNO_H
#include <disciplina.h>
#include <iostream>
#include <QString>
#include <fstream>
#include <list>

class Aluno
{
private:
    QString matricula;
    QString nome;
    std::list<disciplina> disciplinas;
public:
    Aluno();

};

#endif // ALUNO_H
