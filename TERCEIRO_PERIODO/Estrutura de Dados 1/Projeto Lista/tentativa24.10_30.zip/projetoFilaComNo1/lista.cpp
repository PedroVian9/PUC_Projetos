#include "lista.h"

Lista::Lista():
    quantidadeElementos(0),
    inicio(0)
{
}

bool Lista::estaVazia() const
{
    return (quantidadeElementos == 0);
}

void Lista::inserirFinal(int elemento)
{
    try {
        No *novo = new No(elemento);
        if(estaVazia()) {
            quantidadeElementos++;
            inicio=novo;
            return;
        }
        No *aux = inicio;
        while (aux->getProximo() != 0){
            aux=aux->getProximo();
        }
        aux->setProximo(novo);
        quantidadeElementos++;
    }
     catch (std::bad_alloc &erro) {
        throw QString ("Não foi possível criar o nó - inserirFinal");
    }
}




void Lista::incluirOrdenado(int elemento)
{
    No *aux = new No(elemento);
            quantidadeElementos++;
            aux->setProximo(inicio);
            inicio=aux;
        No* novo = new No(elemento);

            if (inicio == nullptr || elemento < inicio->getDado()) {
                novo->setProximo(inicio);
                inicio = novo;
            } else {
                No* atual = inicio;
                while (atual->getProximo() != nullptr && atual->getProximo()->getDado() < elemento) {
                    atual = atual->getProximo();
                }
                novo->setProximo(atual->getProximo());
                atual->setProximo(novo);
            }

}
void Lista::inserirInicio(int elemento)
{
    try {
        No *aux = new No(elemento);
        quantidadeElementos++;
        aux->setProximo(inicio);
        inicio=aux;
    } catch (std::bad_alloc &erro) {
        throw QString ("Não foi possível criar o nó - inserirInicio");
    }
}

int Lista::retirarInicio()
{
    if(estaVazia())throw QString ("A lista está vazia - retirarInicio");
        No* aux = inicio;
        inicio = aux->getProximo();
        int valor = aux->getDado();
        delete aux;
        quantidadeElementos--;
        return valor;
}

int Lista::getQuantidadeElementos() const
{
 return quantidadeElementos;
}

int Lista::acessarInicio()
{
    if(estaVazia())throw QString ("A lista está vazia");
    return inicio->getDado();
}

QString Lista::obterDadosLLSE() const
{
    if(estaVazia())throw QString ("A lista está vazia");
    QString resultado = " | ";
    No *aux=inicio;
    for(int pos=0;pos<quantidadeElementos;pos++){
        resultado += QString::number(aux->getDado());
        aux = aux->getProximo();
        if(pos < quantidadeElementos-1){
            resultado += " | -> | ";
        }
    }
    resultado += " | ";
    return resultado;
}

int Lista::acessarFinal() const
{
    if(estaVazia())throw QString ("A lista está vazia");
    No *aux=inicio;
    while (aux->getProximo() != 0){
        aux=aux->getProximo();
    }
    return aux->getDado();
}

int Lista::retirarFinal()
{
    if(estaVazia())throw QString ("A lista está vazia - retirarFinal");
    if(quantidadeElementos==1){
        int valor = inicio->getDado();
        delete inicio;
        quantidadeElementos=0;
        inicio=0;
        return valor;
    }
    No *aux = inicio;
    while (aux->getProximo()->getProximo() != 0){
        aux = aux->getProximo();
    }
    int valor = aux->getProximo()->getDado();
    delete aux->getProximo();
    aux->setProximo(0);
    quantidadeElementos--;
    return valor;
}


