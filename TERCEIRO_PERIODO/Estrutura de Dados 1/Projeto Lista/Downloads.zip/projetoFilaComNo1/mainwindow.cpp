#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "lista.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

Lista Lista;

void MainWindow::on_pushButtonIncluirInicio_clicked()
{
    try {
            int dado=0;
            if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");
            dado = ui->lineEditValor->text().toInt();
            Lista.inserirInicio(dado);
            ui->textEditMostrarLista->setText((Lista.obterDadosLLSE()));
            ui->lineEditValor->clear();
            ui->lineEditValor->setFocus();
            ui->lineEditQuantidadeDeElementos->setText(QString::number(Lista.getQuantidadeElementos()));
        } catch (QString &erro) {
            ui->lineEditQuantidadeDeElementos->setText("0");
            QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
        }
}


void MainWindow::on_pushButtonIncluirFinal_clicked()
{
    try {
           int dado = 0;
           if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");
           dado = ui->lineEditValor->text().toInt();
           Lista.inserirFinal(dado);
           ui->textEditMostrarLista->setText((Lista.obterDadosLLSE()));
           ui->lineEditValor->clear();
           ui->lineEditValor->setFocus();
           ui->lineEditQuantidadeDeElementos->setText(QString::number(Lista.getQuantidadeElementos()));
       }
       catch (QString &erro) {
           ui->lineEditQuantidadeDeElementos->setText("0");
           QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
       }
}


void MainWindow::on_pushButtonAcessarInicio_clicked()
{
    try {
            QString saida = "";
            saida += QString::number(Lista.acessarInicio());
            ui->lineEditValor->setText(saida);
        } catch (QString &erro) {
            QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
        }
}


void MainWindow::on_pushButtonAcessarFinal_clicked()
{
    try {
                QString saida = "";
                saida += QString::number(Lista.acessarFinal());
                ui->lineEditValor->setText(saida);
            } catch (QString &erro) {
                QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
            }
}


void MainWindow::on_pushButtonRetirarinicio_clicked()
{
    try {
            QString saida = "";
            saida += QString::number(Lista.retirarInicio());
            ui->lineEditValor->setText(saida);
            ui->textEditMostrarLista->setText(Lista.obterDadosLLSE());
            ui->lineEditQuantidadeDeElementos->setText(QString::number(Lista.getQuantidadeElementos()));
        } catch (QString &erro) {
        ui->lineEditQuantidadeDeElementos->setText("0");
            ui->textEditMostrarLista->setText("{ A fila está vazia }");
            QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
        }
}


void MainWindow::on_pushButtonRetirarFinal_clicked()
{
    try {
            QString resultado = "";
            resultado += QString::number(Lista.retirarFinal());
            ui->lineEditValor->setText(resultado);
            ui->textEditMostrarLista->setText(Lista.obterDadosLLSE());
            ui->lineEditQuantidadeDeElementos->setText(QString::number(Lista.getQuantidadeElementos()));
        } catch (QString &erro) {
            ui->lineEditQuantidadeDeElementos->setText("0");
            ui->textEditMostrarLista->setText("{ A fila está vazia }");
            QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
}
}


void MainWindow::on_pushButtoNAcessarPos_clicked()
{
    try {
        int posicao = 0;
            QString saida = "";
            posicao = ui->lineEditPosicao->text().toInt();
            saida += QString::number(Lista.acessarPosicao(posicao));
            ui->lineEditValor->setText(saida);
            posicao = ui->lineEditPosicao->text().toInt();
        } catch (QString &erro) {
            QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
        }
}


void MainWindow::on_pushButtonIncluirPos_clicked()
{
    try {
            int posicao = 0;
            int dado=0;
            if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");
            dado = ui->lineEditValor->text().toInt();
            posicao = ui->lineEditPosicao->text().toInt();
            Lista.incluirPosicao(dado, posicao);
            ui->textEditMostrarLista->setText((Lista.obterDadosLLSE()));
            ui->lineEditValor->clear();
            ui->lineEditValor->setFocus();
            ui->lineEditQuantidadeDeElementos->setText(QString::number(Lista.getQuantidadeElementos()));
        } catch (QString &erro) {
            ui->lineEditQuantidadeDeElementos->setText("0");
            QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
        }
}


void MainWindow::on_pushButtonRetirarPos_clicked()
{
    try {
            int posicao = 0;
            QString resultado = "";
            posicao = ui->lineEditPosicao->text().toInt();
            resultado += QString::number(Lista.retirarPosicao(posicao));
            ui->lineEditValor->setText(resultado);
            ui->textEditMostrarLista->setText(Lista.obterDadosLLSE());
            ui->lineEditQuantidadeDeElementos->setText(QString::number(Lista.getQuantidadeElementos()));
        } catch (QString &erro) {

            ui->lineEditQuantidadeDeElementos->setText("0");
            if(Lista.estaVazia()){
            ui->textEditMostrarLista->setText("{ A fila está vazia }");
            }
            QMessageBox::critical(this,"ERRO DO SISTEMA",erro);

}
}

