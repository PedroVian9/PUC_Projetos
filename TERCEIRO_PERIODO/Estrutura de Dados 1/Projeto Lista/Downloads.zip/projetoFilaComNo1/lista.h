#ifndef LISTA_H
#define LISTA_H
#include "no.h"
#include <QString>

class Lista
{
private:
    int quantidadeElementos;
    No* inicio;

public:
    Lista();
    bool estaVazia()const;
    void inserirInicio(int elemento);
    int retirarInicio();
    int getQuantidadeElementos() const;
    int acessarInicio();
    QString obterDadosLLSE()const;
    int acessarFinal()const;
    int retirarFinal();
    void inserirFinal(int elemento);

    int acessarPosicao(int posicao);
    void incluirPosicao(int valor, int posicao);
    int retirarPosicao(int posicao);
};

#endif
