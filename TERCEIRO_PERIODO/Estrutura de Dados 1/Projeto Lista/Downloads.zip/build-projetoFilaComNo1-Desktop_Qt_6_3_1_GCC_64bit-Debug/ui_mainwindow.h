/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_7;
    QTextEdit *textEditMostrarLista;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QPushButton *pushButtonIncluirInicio;
    QPushButton *pushButtonIncluirFinal;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_4;
    QPushButton *pushButtonRetirarinicio;
    QPushButton *pushButtonRetirarFinal;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_3;
    QPushButton *pushButtonAcessarInicio;
    QPushButton *pushButtonAcessarFinal;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_6;
    QLineEdit *lineEditQuantidadeDeElementos;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout;
    QLabel *label_5;
    QLineEdit *lineEditValor;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_9;
    QLineEdit *lineEditPosicao;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_8;
    QPushButton *pushButtoNAcessarPos;
    QPushButton *pushButtonRetirarPos;
    QPushButton *pushButtonIncluirPos;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(250, 10, 301, 71));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(100, 300, 181, 31));
        textEditMostrarLista = new QTextEdit(centralwidget);
        textEditMostrarLista->setObjectName(QString::fromUtf8("textEditMostrarLista"));
        textEditMostrarLista->setGeometry(QRect(100, 330, 601, 121));
        textEditMostrarLista->setReadOnly(true);
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(100, 90, 100, 90));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        pushButtonIncluirInicio = new QPushButton(layoutWidget);
        pushButtonIncluirInicio->setObjectName(QString::fromUtf8("pushButtonIncluirInicio"));

        verticalLayout->addWidget(pushButtonIncluirInicio);

        pushButtonIncluirFinal = new QPushButton(layoutWidget);
        pushButtonIncluirFinal->setObjectName(QString::fromUtf8("pushButtonIncluirFinal"));

        verticalLayout->addWidget(pushButtonIncluirFinal);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(390, 90, 103, 90));
        verticalLayout_3 = new QVBoxLayout(layoutWidget1);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_3->addWidget(label_4);

        pushButtonRetirarinicio = new QPushButton(layoutWidget1);
        pushButtonRetirarinicio->setObjectName(QString::fromUtf8("pushButtonRetirarinicio"));

        verticalLayout_3->addWidget(pushButtonRetirarinicio);

        pushButtonRetirarFinal = new QPushButton(layoutWidget1);
        pushButtonRetirarFinal->setObjectName(QString::fromUtf8("pushButtonRetirarFinal"));

        verticalLayout_3->addWidget(pushButtonRetirarFinal);

        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(240, 90, 106, 90));
        verticalLayout_2 = new QVBoxLayout(layoutWidget2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_2->addWidget(label_3);

        pushButtonAcessarInicio = new QPushButton(layoutWidget2);
        pushButtonAcessarInicio->setObjectName(QString::fromUtf8("pushButtonAcessarInicio"));

        verticalLayout_2->addWidget(pushButtonAcessarInicio);

        pushButtonAcessarFinal = new QPushButton(layoutWidget2);
        pushButtonAcessarFinal->setObjectName(QString::fromUtf8("pushButtonAcessarFinal"));

        verticalLayout_2->addWidget(pushButtonAcessarFinal);

        layoutWidget3 = new QWidget(centralwidget);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(100, 250, 424, 30));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(layoutWidget3);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_2->addWidget(label_6);

        lineEditQuantidadeDeElementos = new QLineEdit(layoutWidget3);
        lineEditQuantidadeDeElementos->setObjectName(QString::fromUtf8("lineEditQuantidadeDeElementos"));

        horizontalLayout_2->addWidget(lineEditQuantidadeDeElementos);

        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(100, 210, 451, 29));
        horizontalLayout_4 = new QHBoxLayout(widget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout->addWidget(label_5);

        lineEditValor = new QLineEdit(widget);
        lineEditValor->setObjectName(QString::fromUtf8("lineEditValor"));

        horizontalLayout->addWidget(lineEditValor);


        horizontalLayout_4->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_3->addWidget(label_9);

        lineEditPosicao = new QLineEdit(widget);
        lineEditPosicao->setObjectName(QString::fromUtf8("lineEditPosicao"));

        horizontalLayout_3->addWidget(lineEditPosicao);


        horizontalLayout_4->addLayout(horizontalLayout_3);

        widget1 = new QWidget(centralwidget);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(530, 90, 97, 114));
        verticalLayout_4 = new QVBoxLayout(widget1);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(widget1);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_4->addWidget(label_8);

        pushButtoNAcessarPos = new QPushButton(widget1);
        pushButtoNAcessarPos->setObjectName(QString::fromUtf8("pushButtoNAcessarPos"));

        verticalLayout_4->addWidget(pushButtoNAcessarPos);

        pushButtonRetirarPos = new QPushButton(widget1);
        pushButtonRetirarPos->setObjectName(QString::fromUtf8("pushButtonRetirarPos"));

        verticalLayout_4->addWidget(pushButtonRetirarPos);

        pushButtonIncluirPos = new QPushButton(widget1);
        pushButtonIncluirPos->setObjectName(QString::fromUtf8("pushButtonIncluirPos"));

        verticalLayout_4->addWidget(pushButtonIncluirPos);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 20));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:700;\">SISTEMA TESTE LISTA</span></p></body></html>", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">MOSTRAR LISTA:</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">INCLUIR</span></p></body></html>", nullptr));
        pushButtonIncluirInicio->setText(QCoreApplication::translate("MainWindow", "INCLUIR INICIO", nullptr));
        pushButtonIncluirFinal->setText(QCoreApplication::translate("MainWindow", "INCLUIR FINAL", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">RETIRAR</span></p></body></html>", nullptr));
        pushButtonRetirarinicio->setText(QCoreApplication::translate("MainWindow", "RETIRAR INICIO", nullptr));
        pushButtonRetirarFinal->setText(QCoreApplication::translate("MainWindow", "RETIRAR FINAL", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">ACESSAR</span></p></body></html>", nullptr));
        pushButtonAcessarInicio->setText(QCoreApplication::translate("MainWindow", "ACESSAR INICIO", nullptr));
        pushButtonAcessarFinal->setText(QCoreApplication::translate("MainWindow", "ACESSAR FINAL", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">QUANTIDADE DE ELEMENTOS: </span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">VALOR:</span></p></body></html>", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">POSI\303\207\303\203O:</span></p></body></html>", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">POSI\303\207\303\203O</span></p></body></html>", nullptr));
        pushButtoNAcessarPos->setText(QCoreApplication::translate("MainWindow", "ACESSAR POS.", nullptr));
        pushButtonRetirarPos->setText(QCoreApplication::translate("MainWindow", "RETIRAR POS.", nullptr));
        pushButtonIncluirPos->setText(QCoreApplication::translate("MainWindow", "INCLUIR POS.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
