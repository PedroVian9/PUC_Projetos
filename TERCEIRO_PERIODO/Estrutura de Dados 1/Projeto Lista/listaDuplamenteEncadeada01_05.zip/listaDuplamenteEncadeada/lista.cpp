#include "lista.h"


lista::lista():
    quantidadeElementos(0),
    inicio(0),
    fim(0)
{
}

bool lista::estaVazia()const{
    return (quantidadeElementos==0);
}
void lista::inserirInicio(int elemento){
    try{
             no *aux = new no(elemento);
             if(estaVazia())
             {
                 inicio = fim = aux;
                 quantidadeElementos++;
                 return;
             }
             inicio->setAnterior(aux);
             aux->setProximo(inicio);
             inicio = aux;
             quantidadeElementos++;
         }catch (std::bad_alloc &erro)
         {
             throw QString("Nao foi possivel alocar memoria - inserirInicio");
         }
}
void lista::inserirFinal(int elemento){
    try {
        no *aux = new no (elemento);
        if(estaVazia()){
            inicio = fim = aux;
            quantidadeElementos++;
            return;
        }
        fim->setProximo(aux);
        aux->setAnterior(fim);
        quantidadeElementos++;
        fim = aux;
    }catch (std::bad_alloc &erro)
    {
        throw QString("Nao foi possivel alocar memoria - inserirFinal");
    }
}
int lista::acessarInicio()const{
    if(estaVazia()) throw QString ("A lista está vazia - acessarInicio");
    return inicio->getDado();
}
int lista::acessarFinal()const{
    if(estaVazia()) throw QString ("A lista está vazia - acessarFinal");
    return fim->getDado();
}
int lista::retirarInicio(){
    if(estaVazia()) throw QString ("A lista está vazia - retirarInicio");
    int valor = inicio->getDado();
    if(quantidadeElementos==1){
        delete inicio;
        fim = inicio = 0;
        quantidadeElementos--;
        return valor;
    }
    inicio=inicio->getProximo();
    delete inicio->getAnterior();
    inicio->setAnterior(0);
    quantidadeElementos--;
    return valor;
}

int lista::getQuantidadeElementos() const
{
    return quantidadeElementos;
}
int lista::retirarFinal(){
    if(estaVazia()) throw QString ("A lista está vazia - retirarFinal");
    no *aux=fim;
    if(quantidadeElementos==1){
    quantidadeElementos=0;
    inicio=fim=0;
    int valor = aux->getDado();
    delete aux;
    return valor;
    }
    fim->getAnterior()->setProximo(0);
    fim=aux->getAnterior();
    int valor = aux->getDado();
    delete aux;
    quantidadeElementos--;
    return valor;
}

int lista::acessarPosicao(int posicao)
{
    if(estaVazia()) throw QString("A lista está vazia");

        if(posicao < 0) throw QString ("Fora do intervalo");
        if(posicao >= quantidadeElementos) throw QString ("Fora do intervalo");
        if (posicao == 0) return acessarInicio();
        if(posicao == quantidadeElementos - 1) return acessarFinal();

        no* aux = inicio;
        for(int p = 0; p < posicao; p++) {
            aux = aux->getProximo();
        }
        return aux->getDado();
}

int lista::retirarPosicao(int posicao)
{
    if (estaVazia()) throw QString("A lista está vazia");
    if (posicao < 0 || posicao >= quantidadeElementos) throw QString("Posição inválida");
    no* atual = inicio;
    for (int i = 0; i < posicao; i++) {
        atual = atual->getProximo();
    }

    if (atual == inicio) {
        inicio = atual->getProximo();
        if (inicio) inicio->setAnterior(0);
    }
    else if (atual == fim) {
        fim = atual->getAnterior();
        fim->setProximo(0);
    }
    else {
        atual->getAnterior()->setProximo(atual->getProximo());
        atual->getProximo()->setAnterior(atual->getAnterior());
    }

    int valor = atual->getDado();
    delete atual;
    quantidadeElementos--;
    return valor;
}

void lista::inserirPosicao(int posicao, int elemento)
{
        if (posicao < 0 || posicao >= quantidadeElementos) {
            throw QString("Posição inválida");
        }

        if (posicao == 0) {
            return inserirInicio(elemento);
        }

        if (posicao == quantidadeElementos - 1) {
            return inserirFinal(elemento);
        }

        no* novoNo = new no(elemento);
        no* atual = inicio;
        for (int i = 0; i < posicao-1; i++) {
            atual = atual->getProximo();
        }
        novoNo->setProximo(atual->getProximo());
        novoNo->setAnterior(atual);
        atual->getProximo()->setAnterior(novoNo);
        atual->setProximo(novoNo);
        quantidadeElementos++;
}

void lista::inserirOrdenado(int elemento)
{
    no* novo = new no(elemento);

        if (inicio == nullptr) {
            inicio = novo;
            fim = novo;
        } else if (elemento < inicio->getDado()) {
            novo->setProximo(inicio);
            inicio->setAnterior(novo);
            inicio = novo;
        } else {
            no* atual = inicio;
            while (atual->getProximo() != nullptr && atual->getProximo()->getDado() < elemento) {
                atual = atual->getProximo();
            }
            if (atual->getProximo() == nullptr) {
                fim = novo;
            } else {
                atual->getProximo()->setAnterior(novo);
            }
            novo->setProximo(atual->getProximo());
            novo->setAnterior(atual);
            atual->setProximo(novo);
        }

        quantidadeElementos++;
}

QString lista::obterLista()const{
    QString resultado = " | ";
    no *aux=inicio;
    for(int pos=0;pos<quantidadeElementos;pos++){
        resultado += QString::number(aux->getDado());
        aux = aux->getProximo();
        if(pos < quantidadeElementos-1){
            resultado += " | -> | ";
        }
    }
    resultado += " | ";
    if(quantidadeElementos==0) resultado = "{ A lista está vazia }";
    return resultado;
}
