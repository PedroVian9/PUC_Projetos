#ifndef NO_H
#define NO_H
#include <QString>

class no
{
private:
    int dado;
    no *proximo;
    no *anterior;
public:
    no();
    no(int dado);
    no *getProximo() const;
    void setProximo(no *newProximo);
    no *getAnterior() const;
    void setAnterior(no *newAnterior);
    int getDado() const;
    void setDado(int newDado);
};

#endif // NO_H
