#include "mainwindow.h"
#include "lista.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

lista lista;

void MainWindow::on_pushButtonIncluirInicio_clicked()
{
    try {
            int dado=0;
            if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");
            dado = ui->lineEditValor->text().toInt();
            lista.inserirInicio(dado);
            ui->textEditMostrarLista->setText(lista.obterLista());
            ui->lineEditQuantidadeDeElementos->setText(QString::number(lista.getQuantidadeElementos()));
            ui->lineEditValor->clear();
            ui->lineEditValor->setFocus();
        } catch (QString &erro ) {
            QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
        }
}


void MainWindow::on_pushButtonIncluirFinal_clicked()
{
    try {
            int dado=0;
            if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");
            dado = ui->lineEditValor->text().toInt();
            lista.inserirFinal(dado);
            ui->textEditMostrarLista->setText(lista.obterLista());
            ui->lineEditQuantidadeDeElementos->setText(QString::number(lista.getQuantidadeElementos()));
            ui->lineEditValor->clear();
            ui->lineEditValor->setFocus();
        } catch (QString &erro ) {
            QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
        }
}


void MainWindow::on_pushButtonAcessarInicio_clicked()
{
    try {
            ui->lineEditValor->setText(QString::number(lista.acessarInicio()));
        } catch (QString &erro) {
            QMessageBox::critical(this, "ERRO DO SISTEMA",erro);
        }
}


void MainWindow::on_pushButtonAcessarFinal_clicked()
{

    try {
        ui->lineEditValor->setText(QString::number(lista.acessarFinal()));
    } catch (QString &erro) {
        QMessageBox::critical(this, "ERRO DO SISTEMA",erro);
    }
}


void MainWindow::on_pushButtonRetirarinicio_clicked()
{
    try {
           ui->lineEditValor->setText(QString::number(lista.retirarInicio()));
           ui->lineEditQuantidadeDeElementos->setText(QString::number(lista.getQuantidadeElementos()));
           ui->textEditMostrarLista->setText(lista.obterLista());
       } catch (QString &erro) {
           QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
       }
}


void MainWindow::on_pushButtonRetirarFinal_clicked()
{
    try {
           ui->lineEditValor->setText(QString::number(lista.retirarFinal()));
           ui->lineEditQuantidadeDeElementos->setText(QString::number(lista.getQuantidadeElementos()));
           ui->textEditMostrarLista->setText(lista.obterLista());
       } catch (QString &erro) {
           QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
       }
}


void MainWindow::on_pushButton_4_clicked()
{
    try {
                int dado = 0;
                if(ui->lineEditValor->text().isEmpty()){
                    ui->lineEditValor->setFocus();
                    throw QString ("Por favor insira algum numero inteiro");
                }
                dado = ui->lineEditValor->text().toInt();
                lista.inserirOrdenado(dado);
                ui->textEditMostrarLista->setText((lista.obterLista()));
                ui->lineEditQuantidadeDeElementos->setText(QString::number(lista.getQuantidadeElementos()));
                ui->lineEditValor->clear();
                ui->lineEditValor->setFocus();
            } catch (QString &erro) {
                QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
            }
}


void MainWindow::on_pushButtonIncluirPosicao_clicked()
{
    try {
               int posicao;
               int dado=0;
               if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");

               dado = ui->lineEditValor->text().toInt();
               posicao = ui->lineEditPosicao->text().toInt();
               lista.inserirPosicao(posicao, dado);
               ui->textEditMostrarLista->setText((lista.obterLista()));
               ui->lineEditValor->clear();
               ui->lineEditValor->setFocus();
               ui->lineEditQuantidadeDeElementos->setText(QString::number(lista.getQuantidadeElementos()));
           } catch (QString &erro) {
               ui->lineEditQuantidadeDeElementos->setText("0");
               QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
           }
}


void MainWindow::on_pushButtonAcessarPos_clicked()
{
    try {
            int posicao = 0;
                QString saida = "";
                posicao = ui->lineEditPosicao->text().toInt();
                saida += QString::number(lista.acessarPosicao(posicao));
                ui->lineEditValor->setText(saida);
                posicao = ui->lineEditPosicao->text().toInt();
            } catch (QString &erro) {
                QMessageBox::critical(this,"ERRO DO SISTEMA",erro);
            }
}


void MainWindow::on_pushButtonRetirarPos_clicked()
{
    try {
                int posicao = 0;
                QString resultado = "";
                posicao = ui->lineEditPosicao->text().toInt();
                resultado += QString::number(lista.retirarPosicao(posicao));
                ui->lineEditValor->setText(resultado);
                ui->textEditMostrarLista->setText(lista.obterLista());
                ui->lineEditQuantidadeDeElementos->setText(QString::number(lista.getQuantidadeElementos()));
            } catch (QString &erro) {

                ui->lineEditQuantidadeDeElementos->setText("0");
                if(lista.estaVazia()){
                ui->textEditMostrarLista->setText("{ A fila está vazia }");
                }
                QMessageBox::critical(this,"ERRO DO SISTEMA",erro);

    }
}

