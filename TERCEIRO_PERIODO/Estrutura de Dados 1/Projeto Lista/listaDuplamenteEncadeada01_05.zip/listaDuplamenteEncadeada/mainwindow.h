#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMessageBox>
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButtonIncluirInicio_clicked();

    void on_pushButtonIncluirFinal_clicked();

    void on_pushButtonAcessarInicio_clicked();

    void on_pushButtonAcessarFinal_clicked();

    void on_pushButtonRetirarinicio_clicked();

    void on_pushButtonRetirarFinal_clicked();

    void on_pushButton_4_clicked();

    void on_pushButtonIncluirPosicao_clicked();

    void on_pushButtonAcessarPos_clicked();

    void on_pushButtonRetirarPos_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
