#ifndef LISTA_H
#define LISTA_H
#include <QString>
#include <no.h>

class lista
{
private:
    int quantidadeElementos;
    no *inicio;
    no *fim;
public:
    lista();
    QString obterLista()const;
        bool estaVazia()const;
        void inserirInicio(int elemento);
        int acessarInicio()const;
        int retirarInicio();
        int getQuantidadeElementos() const;
        void inserirFinal(int elemento);
        int acessarFinal()const;
        int retirarFinal();

        int acessarPosicao(int posicao);
        int retirarPosicao(int posicao);
        void inserirPosicao(int posicao, int elemento);
        void inserirOrdenado(int elemento);
};

#endif // LISTA_H
