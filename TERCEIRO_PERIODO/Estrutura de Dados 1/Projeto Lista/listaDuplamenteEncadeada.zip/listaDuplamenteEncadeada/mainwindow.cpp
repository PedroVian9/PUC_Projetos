#include "mainwindow.h"
#include "lista.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

lista lista;

void MainWindow::on_pushButtonIncluirInicio_clicked()
{
    try {
            int dado=0;
            if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");
            dado = ui->lineEditValor->text().toInt();
            lista.inserirInicio(dado);
            ui->textEditMostrarLista->setText(lista.obterLista());
            ui->lineEditValor->clear();
            ui->lineEditValor->setFocus();
        } catch (QString &erro ) {
            QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
        }
}


void MainWindow::on_pushButtonIncluirFinal_clicked()
{
    try {
            int dado=0;
            if(ui->lineEditValor->text().isEmpty()) throw QString ("Insira um valor para preencher a lista");
            dado = ui->lineEditValor->text().toInt();
            lista.inserirFinal(dado);
            ui->textEditMostrarLista->setText(lista.obterLista());
            ui->lineEditValor->clear();
            ui->lineEditValor->setFocus();
        } catch (QString &erro ) {
            QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
        }
}


void MainWindow::on_pushButtonAcessarInicio_clicked()
{
    try {
            ui->lineEditValor->setText(QString::number(lista.acessarInicio()));
        } catch (QString &erro) {
            QMessageBox::critical(this, "ERRO DO SISTEMA",erro);
        }
}


void MainWindow::on_pushButtonAcessarFinal_clicked()
{

    try {
        ui->lineEditValor->setText(QString::number(lista.acessarFinal()));
    } catch (QString &erro) {
        QMessageBox::critical(this, "ERRO DO SISTEMA",erro);
    }
}


void MainWindow::on_pushButtonRetirarinicio_clicked()
{
    try {
           ui->lineEditValor->setText(QString::number(lista.retirarInicio()));
           ui->textEditMostrarLista->setText(lista.obterLista());
       } catch (QString &erro) {
           QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
       }
}


void MainWindow::on_pushButtonRetirarFinal_clicked()
{
    try {
           ui->lineEditValor->setText(QString::number(lista.retirarFinal()));
           ui->textEditMostrarLista->setText(lista.obterLista());
       } catch (QString &erro) {
           QMessageBox::critical(this, "ERRO DO SISTEMA", erro);
       }
}

