#include "lista.h"


lista::lista():
    quantidadeElementos(0),
    inicio(0),
    fim(0)
{
}

bool lista::estaVazia()const{
    return (quantidadeElementos==0);
}
void lista::inserirInicio(int elemento){
    try{
             no *aux = new no(elemento);
             if(estaVazia())
             {
                 inicio = fim = aux;
                 quantidadeElementos++;
                 return;
             }
             inicio->setAnterior(aux);
             aux->setProximo(inicio);
             inicio = aux;
             quantidadeElementos++;
         }catch (std::bad_alloc &erro)
         {
             throw QString("Nao foi possivel alocar memoria - inserirInicio");
         }
}
void lista::inserirFinal(int elemento){
    try {
        no *aux = new no (elemento);
        if(estaVazia()){
            inicio = fim = aux;
            quantidadeElementos++;
            return;
        }
        fim->setProximo(aux);
        aux->setAnterior(fim);
        quantidadeElementos++;
        fim = aux;
    }catch (std::bad_alloc &erro)
    {
        throw QString("Nao foi possivel alocar memoria - inserirFinal");
    }
}
int lista::acessarInicio()const{
    if(estaVazia()) throw QString ("A lista está vazia - acessarInicio");
    return inicio->getDado();
}
int lista::acessarFinal()const{
    if(estaVazia()) throw QString ("A lista está vazia - acessarFinal");
    return fim->getDado();
}
int lista::retirarInicio(){
    if(estaVazia()) throw QString ("A lista está vazia - retirarInicio");
    int valor = inicio->getDado();
    if(quantidadeElementos==1){
        delete inicio;
        fim = inicio = 0;
        quantidadeElementos--;
        return valor;
    }
    inicio=inicio->getProximo();
    delete inicio->getAnterior();
    inicio->setAnterior(0);
    quantidadeElementos--;
    return valor;
}
int lista::retirarFinal(){
    if(estaVazia()) throw QString ("A lista está vazia - retirarFinal");
    no *aux=fim;
    if(quantidadeElementos==1){
    quantidadeElementos=0;
    inicio=fim=0;
    int valor = aux->getDado();
    delete aux;
    return valor;
    }
    fim->getAnterior()->setProximo(0);
    fim=aux->getAnterior();
    int valor = aux->getDado();
    delete aux;
    quantidadeElementos--;
    return valor;
}
QString lista::obterLista()const{
    QString resultado = " | ";
    no *aux=inicio;
    for(int pos=0;pos<quantidadeElementos;pos++){
        resultado += QString::number(aux->getDado());
        aux = aux->getProximo();
        if(pos < quantidadeElementos-1){
            resultado += " | -> | ";
        }
    }
    resultado += " | ";
    if(quantidadeElementos==0) resultado = "{ A lista está vazia }";
    return resultado;
}
