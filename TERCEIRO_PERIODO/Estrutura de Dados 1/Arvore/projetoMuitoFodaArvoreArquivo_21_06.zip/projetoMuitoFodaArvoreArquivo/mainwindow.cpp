#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
#include <iterator>
#include <QFileDialog>
#include <QMessageBox>
#include "MainWindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonBuscarArquivo_clicked()
{
        QString filePath = QFileDialog::getOpenFileName(this, "Selecione o arquivo", "", "CSV ou TXT (*.csv *.txt)");

        if (!filePath.isEmpty())
            // Verifica se o arquivo foi selecionado
        {

            ui->lineEditMostrarEndereco->setText(filePath);
            // Salva o caminho do arquivo em uma variável
            QString caminhoDiretorio = QFileInfo(filePath).path();
            // Atualiza o QLineEdit com o caminho do arquivo selecionado
        }
}
