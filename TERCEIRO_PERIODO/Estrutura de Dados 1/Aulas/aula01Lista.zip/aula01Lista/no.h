#ifndef NO_H
#define NO_H
namespace pv{
class No
{
    //Atributos
private:
    int dado;
    No* proximo;
public:
    No();
    No(int elemento);
    int getDado() const;
    void setDado(int newDado);
    No *getProximo() const;
    void setProximo(No *newProximo);
};
}
#endif // NO_H
