#ifndef PACIENTE_H
#define PACIENTE_H
#include <QString>
namespace ejm{
class Paciente
{
    //Atributos
private:
    QString nomeCompleto;
    int peso;
    float altura;
    QString sexo;

    //Métodos
public:
    Paciente();
    Paciente(QString nomeCompleto, int peso, float altura, QString sexo);
    float calcularIMC()const;
    QString calcularFaixaDeRisco()const;
    float calcularPesoIdeal()const;
};
}
#endif // PACIENTE_H
