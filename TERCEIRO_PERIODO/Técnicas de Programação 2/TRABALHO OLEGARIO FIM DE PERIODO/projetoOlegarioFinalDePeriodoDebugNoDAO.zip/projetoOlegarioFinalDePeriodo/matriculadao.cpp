#include "matriculadao.h"

MatriculaDAO::MatriculaDAO()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    nomeBD = "/Users/olegariocorreadasilvaneto/SistAcad/academico.db";
    db.setDatabaseName(nomeBD);
}
void MatriculaDAO::incluir(Matricula* obj){
    if (!db.open()){
        throw QString("Erro ao abrir o banco de dados");
    }
    QSqlQuery query;
    query.prepare("INSERT INTO matricula (matricula, nome, cod_disciplina, nome_disciplina, "
                  "cod_turma, cod_subt, ano, semestre) VALUES (:mat, :nome, :cod_discip, nome_discip, "
                  ":cod_turma, :cod_subt, :ano, :semestre);");

    query.bindValue(":mat", obj->getAluno().getMatricula());
    query.bindValue(":nome", obj->getAluno().getNome());

    query.bindValue(":codigo_discip", obj->getTurma().getDisciplina().getCodigo());
    query.bindValue(":nome_discip", obj->getTurma().getDisciplina().getNome());

    query.bindValue(":cod_turma", obj->getTurma().getCodigo());
    query.bindValue(":cod_subt", obj->getTurma().getSubTurma());

    query.bindValue(":ano", obj->getAno());
    query.bindValue(":semestre", obj->getSemestre());
    if (!query.exec()){
        db.close();
        throw QString("Erro ao executar a inserção");
    }
    db.close();
}

Matricula *MatriculaDAO::buscar(Matricula *obj)
{
    if (!db.open()){
        throw QString("Erro ao abrir o banco de dados");
    }
    QString matricula(""), nome(""), cod_disciplina(""), cod_turma(""), cod_subt("");
    QSqlQuery query;
    if (obj!=nullptr){
        query.prepare("SELECT * FROM matricula WHERE nome = nome, matricula = :mat, cod_disciplina = :cod_discip,"
                      " cod_turma = :cod_turma, codSubT = :cod_subt;");
        query.bindValue(":mat", obj->getAluno().getMatricula());
        query.bindValue(":nome", obj->getAluno().getMatricula());
        query.bindValue(":cod_discip", obj->getTurma().getDisciplina().getCodigo());
        query.bindValue(":cod_turma", obj->getTurma().getCodigo());
        query.bindValue(":cod_subt", obj->getTurma().getSubTurma());
        if (!query.exec()){
            db.close();
            throw QString("Erro ao executar a consulta");
        }
        while (query.next()){
            matricula = query.value(0).toString();
            nome = query.value(1).toString();
            cod_disciplina = query.value(2).toString();
            cod_turma = query.value(3).toString();
            cod_subt = query.value(4).toString();
        }
        obj->getAluno().setMatricula(matricula);
        obj->getAluno().setNome(nome);
        obj->getTurma().getDisciplina().setCodigo(cod_disciplina);
        obj->getTurma().setCodigo(cod_turma);
        obj->getTurma().setSubTurma(cod_subt);
        db.close();
    }
    if (obj!=nullptr)
        return obj;
    else{
        delete obj;
        return nullptr;
    }
}

void MatriculaDAO::alterar(Matricula *obj)
{
    Matricula* matricula = new Matricula();
    matricula->getTurma().getDisciplina().setCodigo(obj->getTurma().getDisciplina().getCodigo());
    if (this->buscar(matricula)==nullptr){
        throw QString("Matricula não encontrada!");
    }
    else{
        if (!db.open()){
            throw QString("Erro ao abrir o banco de dados");
        }
        QSqlQuery query;
        query.prepare("UPDATE matricula SET matricula = :mat WHERE cod_disciplina :cod_disciplina,"
                      "cod_turma :cod_turma, cod_subturma :cod_subt ;");
        query.bindValue(":mat", obj->getAluno().getMatricula());
        query.bindValue(":cod_discip", obj->getTurma().getDisciplina().getCodigo());
        query.bindValue(":cod_turma", obj->getTurma().getCodigo());
        query.bindValue(":cod_subt", obj->getTurma().getSubTurma());
        if (!query.exec()){
            db.close();
            throw QString("Erro ao executar a update");
        }
        db.close();
        delete obj;
    }
}

Matricula *MatriculaDAO::remover(Matricula *obj)
{
    Matricula* matricula = new Matricula();
    matricula->getAluno().setMatricula(obj->getAluno().getMatricula());
    matricula->getTurma().setCodigo(obj->getTurma().getCodigo());
    matricula->getTurma().getDisciplina().setCodigo(obj->getTurma().getDisciplina().getCodigo());
    if (this->buscar(matricula)==nullptr){
        throw QString("Matricula não encontrada!");
    }
    else{
        if (!db.open()){
            throw QString("Erro ao abrir o banco de dados");
        }
        QSqlQuery query;
        query.prepare("DELETE FROM matricula WHERE matricula = :mat, cod_disciplina :cod_discip, cod_turma :cod_turma ;");
        query.bindValue(":mat", obj->getAluno().getMatricula());
        query.bindValue(":cod_discip", obj->getTurma().getDisciplina().getCodigo());
        query.bindValue("cod_turma", obj->getTurma().getCodigo());
        if (!query.exec()){
            db.close();
            throw QString("Erro ao executar a delete");
        }
        db.close();
        delete obj;
    }
}
