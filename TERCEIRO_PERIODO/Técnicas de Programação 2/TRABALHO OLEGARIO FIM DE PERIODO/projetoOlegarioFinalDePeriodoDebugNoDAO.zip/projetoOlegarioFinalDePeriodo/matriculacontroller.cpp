#include "matriculacontroller.h"
#include "alunocontroller.h"

MatriculaController::MatriculaController()
{

}
void MatriculaController::incluir(QString &mat, QString &cod_disciplina, QString &cod_turma){
    Aluno aluno = *new Aluno(mat);
    Disciplina discip = *new Disciplina(cod_disciplina, "");
    Turma turma = *new Turma(discip, cod_turma, 0);
    matricula = new Matricula(aluno, turma);
    if(MatriculaController::analisar(aluno, turma)==false){
        throw QString("Matricula já consta no banco de dados!");
    }

    matricula->getAluno().setMatricula(mat);
    matricula->getTurma().getDisciplina().setCodigo(cod_disciplina);
    matricula->getTurma().setCodigo(cod_turma);
    QString semestre = mat[5];
    QString ano = "";
    for(int i=0; i<4; i++){
        ano += mat[i];
    }
    matricula->setAno(ano.toInt());
    matricula->setSemestre(semestre.toInt());
    dao.incluir(matricula);
    matricula = nullptr;
}

QString MatriculaController::buscar(QString &cod_disciplina, QString &cod_turma){
    matricula = nullptr;
    Disciplina discip = *new Disciplina(cod_disciplina, "");
    Turma turma = *new Turma(discip, cod_turma, 0);
    matricula->getTurma().setCodigo(cod_turma);
    matricula = dao.buscar(new Matricula(turma));
    if (matricula->getTurma().getDisciplina().getCodigo()!=nullptr & matricula->getTurma().getCodigo()!=nullptr)
        return 0;
    else
        throw QString("Matriculas não encontradas!");
}

void MatriculaController::alterar(QString const &matricula, QString const &cod_disciplina,
                                  QString const &cod_turma, QString const &cod_subturma)
{
    Aluno aluno = *new Aluno(matricula);
    Disciplina discip = *new Disciplina(cod_disciplina,"");
    Turma turma = *new Turma(discip, cod_turma, cod_subturma);
    dao.alterar(new Matricula(aluno, turma));
}

void MatriculaController::remover(QString const &matricula, QString cod_turma, QString cod_disciplina){
    Aluno aluno = *new Aluno(matricula);
    Disciplina discip = *new Disciplina(cod_disciplina,"");
    Turma turma = *new Turma(discip, cod_turma);
    dao.remover(new Matricula(aluno, turma));
}

bool MatriculaController::analisar(const Aluno &aluno, const Turma &turma){
    matricula = nullptr;
    matricula = dao.buscar(new Matricula(aluno, turma));
    if (matricula->getAluno().getMatricula()!=nullptr){
        matricula = nullptr;
        return true;
    }
    matricula = nullptr;
    return false;
}
