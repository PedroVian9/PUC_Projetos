#include "turmacontroller.h"

TurmaController::TurmaController()
{

}
void TurmaController::incluir(QString const &codigo_discip, const QString &codigo_turma){
    Disciplina disciplina = *new Disciplina(codigo_discip);
    turma = new Turma(disciplina, codigo_turma);
    if(TurmaController::analisar(disciplina, codigo)==false){
        throw QString("Turma já consta no banco de dados!");
    }
    turma->setDisciplina(disciplina);
    turma->setCodigo(codigo);
    dao.incluir(turma);
    turma = nullptr;
}

QString TurmaController::buscar(QString const &codigo_discip, const QString &codigo_turma){
    turma = nullptr;
    Disciplina disciplina = *new Disciplina(codigo_discip);
    turma = dao.buscar(new Turma(disciplina, codigo));
    if (TurmaController::analisar(disciplina, codigo)==true)
        return turma->toQString();
    else
        throw QString("Turma não encontrada!");
}

void TurmaController::alterar(QString const &codigo_discip, const QString &codigo_turma){
    Disciplina disciplina = *new Disciplina(codigo_discip);
    dao.alterar(new Turma(disciplina, codigo_turma));
}

void TurmaController::remover(QString const &codigo_discip, const QString &codigo_turma){
    Disciplina disciplina = *new Disciplina(codigo_discip);
    dao.remover(new Turma(disciplina, codigo_turma));
}

bool TurmaController::analisar(const Disciplina &newDisciplina, const QString &codigo){
    turma = nullptr;
    turma = dao.buscar(new Turma(newDisciplina, codigo, subTurma));
    if(turma->getDisciplina().getCodigo()==nullptr){ throw QString("Disciplina não cadastrada no sistema!"); }
    if(turma->getCodigo()!=nullptr){
        delete turma;
        return true;
    }
    delete turma;
    return false;
}
