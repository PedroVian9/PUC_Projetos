/********************************************************************************
** Form generated from reading UI file 'telaprincipal.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TELAPRINCIPAL_H
#define UI_TELAPRINCIPAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TelaPrincipal
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLineEdit *lineEdit;
    QLabel *label;
    QLineEdit *lineEdit_2;
    QLabel *label_2;
    QTableWidget *tableWidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QWidget *tab_2;
    QGroupBox *groupBox;
    QLineEdit *lineEdit_4;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QGroupBox *groupBox_2;
    QLineEdit *lineEdit_5;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QTableWidget *tableWidget_2;
    QWidget *tab_3;
    QGroupBox *groupBox_3;
    QLineEdit *lineEdit_7;
    QLabel *label_7;
    QLabel *label_8;
    QTextBrowser *textBrowser;
    QGroupBox *groupBox_4;
    QLineEdit *lineEdit_8;
    QLabel *label_9;
    QLabel *label_10;
    QTextBrowser *textBrowser_2;
    QLabel *label_11;
    QTextBrowser *textBrowser_3;
    QGroupBox *groupBox_5;
    QLineEdit *lineEdit_9;
    QLabel *label_12;
    QLabel *label_13;
    QLineEdit *lineEdit_10;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *TelaPrincipal)
    {
        if (TelaPrincipal->objectName().isEmpty())
            TelaPrincipal->setObjectName("TelaPrincipal");
        TelaPrincipal->resize(818, 466);
        centralwidget = new QWidget(TelaPrincipal);
        centralwidget->setObjectName("centralwidget");
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName("tabWidget");
        tabWidget->setGeometry(QRect(10, 10, 801, 411));
        tab = new QWidget();
        tab->setObjectName("tab");
        lineEdit = new QLineEdit(tab);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(90, 20, 113, 21));
        label = new QLabel(tab);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 20, 58, 16));
        lineEdit_2 = new QLineEdit(tab);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(90, 60, 401, 21));
        label_2 = new QLabel(tab);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 60, 58, 16));
        tableWidget = new QTableWidget(tab);
        tableWidget->setObjectName("tableWidget");
        tableWidget->setGeometry(QRect(20, 140, 581, 191));
        pushButton = new QPushButton(tab);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(20, 100, 100, 32));
        pushButton_2 = new QPushButton(tab);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(140, 100, 100, 32));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(260, 100, 100, 32));
        pushButton_4 = new QPushButton(tab);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(380, 100, 100, 32));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName("tab_2");
        groupBox = new QGroupBox(tab_2);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(10, 0, 781, 161));
        lineEdit_4 = new QLineEdit(groupBox);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setGeometry(QRect(80, 40, 151, 21));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(20, 80, 58, 16));
        lineEdit_3 = new QLineEdit(groupBox);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(80, 80, 481, 21));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(20, 40, 58, 16));
        pushButton_5 = new QPushButton(groupBox);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(20, 111, 131, 41));
        pushButton_6 = new QPushButton(groupBox);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(170, 110, 121, 41));
        pushButton_7 = new QPushButton(groupBox);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(310, 110, 111, 41));
        pushButton_8 = new QPushButton(groupBox);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(430, 110, 131, 41));
        groupBox_2 = new QGroupBox(tab_2);
        groupBox_2->setObjectName("groupBox_2");
        groupBox_2->setGeometry(QRect(10, 160, 781, 211));
        lineEdit_5 = new QLineEdit(groupBox_2);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setGeometry(QRect(70, 30, 113, 21));
        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(20, 30, 58, 16));
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(200, 30, 71, 16));
        lineEdit_6 = new QLineEdit(groupBox_2);
        lineEdit_6->setObjectName("lineEdit_6");
        lineEdit_6->setGeometry(QRect(270, 30, 31, 21));
        pushButton_9 = new QPushButton(groupBox_2);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(20, 70, 121, 41));
        pushButton_10 = new QPushButton(groupBox_2);
        pushButton_10->setObjectName("pushButton_10");
        pushButton_10->setGeometry(QRect(160, 70, 100, 41));
        pushButton_11 = new QPushButton(groupBox_2);
        pushButton_11->setObjectName("pushButton_11");
        pushButton_11->setGeometry(QRect(280, 70, 100, 41));
        pushButton_12 = new QPushButton(groupBox_2);
        pushButton_12->setObjectName("pushButton_12");
        pushButton_12->setGeometry(QRect(390, 70, 111, 41));
        tableWidget_2 = new QTableWidget(groupBox_2);
        tableWidget_2->setObjectName("tableWidget_2");
        tableWidget_2->setGeometry(QRect(20, 120, 541, 81));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName("tab_3");
        groupBox_3 = new QGroupBox(tab_3);
        groupBox_3->setObjectName("groupBox_3");
        groupBox_3->setGeometry(QRect(10, 0, 771, 71));
        lineEdit_7 = new QLineEdit(groupBox_3);
        lineEdit_7->setObjectName("lineEdit_7");
        lineEdit_7->setGeometry(QRect(80, 30, 113, 21));
        label_7 = new QLabel(groupBox_3);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(10, 30, 58, 16));
        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(210, 30, 58, 16));
        textBrowser = new QTextBrowser(groupBox_3);
        textBrowser->setObjectName("textBrowser");
        textBrowser->setGeometry(QRect(260, 30, 491, 21));
        groupBox_4 = new QGroupBox(tab_3);
        groupBox_4->setObjectName("groupBox_4");
        groupBox_4->setGeometry(QRect(10, 80, 771, 151));
        lineEdit_8 = new QLineEdit(groupBox_4);
        lineEdit_8->setObjectName("lineEdit_8");
        lineEdit_8->setGeometry(QRect(80, 30, 113, 21));
        label_9 = new QLabel(groupBox_4);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(10, 30, 58, 16));
        label_10 = new QLabel(groupBox_4);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(210, 30, 41, 16));
        textBrowser_2 = new QTextBrowser(groupBox_4);
        textBrowser_2->setObjectName("textBrowser_2");
        textBrowser_2->setGeometry(QRect(260, 30, 491, 21));
        label_11 = new QLabel(groupBox_4);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(130, 70, 131, 20));
        textBrowser_3 = new QTextBrowser(groupBox_4);
        textBrowser_3->setObjectName("textBrowser_3");
        textBrowser_3->setGeometry(QRect(260, 70, 461, 71));
        groupBox_5 = new QGroupBox(tab_3);
        groupBox_5->setObjectName("groupBox_5");
        groupBox_5->setGeometry(QRect(10, 240, 771, 141));
        lineEdit_9 = new QLineEdit(groupBox_5);
        lineEdit_9->setObjectName("lineEdit_9");
        lineEdit_9->setGeometry(QRect(80, 30, 113, 21));
        label_12 = new QLabel(groupBox_5);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(10, 30, 58, 16));
        label_13 = new QLabel(groupBox_5);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(10, 70, 71, 16));
        lineEdit_10 = new QLineEdit(groupBox_5);
        lineEdit_10->setObjectName("lineEdit_10");
        lineEdit_10->setGeometry(QRect(80, 70, 31, 21));
        pushButton_13 = new QPushButton(groupBox_5);
        pushButton_13->setObjectName("pushButton_13");
        pushButton_13->setGeometry(QRect(10, 100, 100, 32));
        pushButton_14 = new QPushButton(groupBox_5);
        pushButton_14->setObjectName("pushButton_14");
        pushButton_14->setGeometry(QRect(120, 100, 100, 32));
        pushButton_15 = new QPushButton(groupBox_5);
        pushButton_15->setObjectName("pushButton_15");
        pushButton_15->setGeometry(QRect(230, 100, 131, 32));
        pushButton_16 = new QPushButton(groupBox_5);
        pushButton_16->setObjectName("pushButton_16");
        pushButton_16->setGeometry(QRect(370, 100, 141, 32));
        tabWidget->addTab(tab_3, QString());
        TelaPrincipal->setCentralWidget(centralwidget);
        menubar = new QMenuBar(TelaPrincipal);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 818, 21));
        TelaPrincipal->setMenuBar(menubar);
        statusbar = new QStatusBar(TelaPrincipal);
        statusbar->setObjectName("statusbar");
        TelaPrincipal->setStatusBar(statusbar);

        retranslateUi(TelaPrincipal);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(TelaPrincipal);
    } // setupUi

    void retranslateUi(QMainWindow *TelaPrincipal)
    {
        TelaPrincipal->setWindowTitle(QCoreApplication::translate("TelaPrincipal", "TelaPrincipal", nullptr));
        label->setText(QCoreApplication::translate("TelaPrincipal", "Matr\303\255cula:", nullptr));
        label_2->setText(QCoreApplication::translate("TelaPrincipal", "Nome:", nullptr));
        pushButton->setText(QCoreApplication::translate("TelaPrincipal", "Cadastrar", nullptr));
        pushButton_2->setText(QCoreApplication::translate("TelaPrincipal", "Buscar", nullptr));
        pushButton_3->setText(QCoreApplication::translate("TelaPrincipal", "Alterar", nullptr));
        pushButton_4->setText(QCoreApplication::translate("TelaPrincipal", "Remover", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("TelaPrincipal", "Aluno", nullptr));
        groupBox->setTitle(QCoreApplication::translate("TelaPrincipal", "Disciplina", nullptr));
        label_4->setText(QCoreApplication::translate("TelaPrincipal", "Nome:", nullptr));
        label_3->setText(QCoreApplication::translate("TelaPrincipal", "C\303\263digo:", nullptr));
        pushButton_5->setText(QCoreApplication::translate("TelaPrincipal", "Cadastrar Disciplina", nullptr));
        pushButton_6->setText(QCoreApplication::translate("TelaPrincipal", "Buscar Disciplina", nullptr));
        pushButton_7->setText(QCoreApplication::translate("TelaPrincipal", "Alterar Disciplina", nullptr));
        pushButton_8->setText(QCoreApplication::translate("TelaPrincipal", "Remover Disciplina", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("TelaPrincipal", "Turmas", nullptr));
        label_5->setText(QCoreApplication::translate("TelaPrincipal", "C\303\263digo:", nullptr));
        label_6->setText(QCoreApplication::translate("TelaPrincipal", "Sub-Turma:", nullptr));
        pushButton_9->setText(QCoreApplication::translate("TelaPrincipal", "Cadastrar Turma", nullptr));
        pushButton_10->setText(QCoreApplication::translate("TelaPrincipal", "Listar Turmas", nullptr));
        pushButton_11->setText(QCoreApplication::translate("TelaPrincipal", "Alterar Turma", nullptr));
        pushButton_12->setText(QCoreApplication::translate("TelaPrincipal", "Remover Turma", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("TelaPrincipal", "Disciplina/Turma", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("TelaPrincipal", "Aluno", nullptr));
        label_7->setText(QCoreApplication::translate("TelaPrincipal", "Matr\303\255cula:", nullptr));
        label_8->setText(QCoreApplication::translate("TelaPrincipal", "Nome:", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("TelaPrincipal", "Disciplina", nullptr));
        label_9->setText(QCoreApplication::translate("TelaPrincipal", "C\303\263digo:", nullptr));
        label_10->setText(QCoreApplication::translate("TelaPrincipal", "Nome:", nullptr));
        label_11->setText(QCoreApplication::translate("TelaPrincipal", "Turmas/Sub-Turmas:", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("TelaPrincipal", "Matr\303\255cula", nullptr));
        label_12->setText(QCoreApplication::translate("TelaPrincipal", "Turma:", nullptr));
        label_13->setText(QCoreApplication::translate("TelaPrincipal", "Sub-turma:", nullptr));
        pushButton_13->setText(QCoreApplication::translate("TelaPrincipal", "Matricular", nullptr));
        pushButton_14->setText(QCoreApplication::translate("TelaPrincipal", "Buscar", nullptr));
        pushButton_15->setText(QCoreApplication::translate("TelaPrincipal", "Alterar Matr\303\255cula", nullptr));
        pushButton_16->setText(QCoreApplication::translate("TelaPrincipal", "Cancelar Matr\303\255cula", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("TelaPrincipal", "Matr\303\255cula", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TelaPrincipal: public Ui_TelaPrincipal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TELAPRINCIPAL_H
