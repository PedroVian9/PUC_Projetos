#ifndef MATRICULA_H
#define MATRICULA_H

#include <QString>
#include "aluno.h"
#include "turma.h"

class Matricula
{
public:
    Matricula();
    Matricula(Turma newTurma);
    Matricula(Aluno newAluno, Turma newTurma);
    Matricula(Aluno newAluno, Turma newTurma,
              int ano, int semestre);
    Aluno getAluno() const;
    void setAluno(Aluno newAluno);

    Turma getTurma() const;
    void setTurma(const Turma &newTurma);

    int getAno() const;
    void setAno(int newAno);

    int getSemestre() const;
    void setSemestre(int newSemestre);

    float getNota1() const;
    void setNota1(float newNota1);

    float getNota2() const;
    void setNota2(float newNota2);

    inline float getMedia() const{
        return (nota1/nota2)/2;
    }

    QString toQString()const;

private:
    Aluno aluno;
    Turma turma;
    int ano;
    int semestre;
    float nota1;
    float nota2;
};


#endif // MATRICULA_H
