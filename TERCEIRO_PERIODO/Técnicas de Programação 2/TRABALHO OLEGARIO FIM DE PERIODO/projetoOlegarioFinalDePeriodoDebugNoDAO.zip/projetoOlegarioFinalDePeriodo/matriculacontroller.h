#ifndef MATRICULACONTROLLER_H
#define MATRICULACONTROLLER_H

#include <QString>
#include "matricula.h"
#include "matriculadao.h"

class MatriculaController
{
public:
    MatriculaController();
    void incluir(QString &mat, QString &cod_disciplina, QString &cod_turma);
    QString buscar(QString &cod_disciplina, QString &cod_turma);
    void alterar(QString const &newAluno, QString const &newTurma, const QString &cod_turma, const QString &cod_subturma);
    void remover(QString const &matricula, QString cod_turma, QString cod_disciplina);
    bool analisar(const Aluno &aluno, const Turma &turma);
private:
    Matricula* matricula;
    MatriculaDAO dao;
};

#endif // MATRICULACONTROLLER_H
