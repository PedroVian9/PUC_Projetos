#ifndef TURMACONTROLLER_H
#define TURMACONTROLLER_H
#include "turma.h"
#include "turmadao.h"
#include <QString>

Disciplina disciplina;
QString codigo;
QString subTurma;
int numMax;
int numAlunos;

class TurmaController
{
public:
    TurmaController();
    void incluir(const QString &codigo_discip, const QString &codigo_turma);
    QString buscar(const QString &codigo_discip, const QString &codigo_turma);
    void alterar(QString const &codigo_discip, const QString &codigo_turma);
    void remover(QString const &codigo_discip, const QString &codigo_turma);
    bool analisar(const Disciplina &newDisciplina, const QString &codigo);
private:
    Turma* turma;
    TurmaDAO dao;
};

#endif // TURMACONTROLLER_H
