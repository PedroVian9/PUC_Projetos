#include "disciplina.h"

Disciplina::Disciplina()
{

}
Disciplina::Disciplina(QString cod)
{
    codigo=cod;
}

Disciplina::Disciplina(QString cod, QString nom){
    codigo=cod;
    nome=nom;
}

QString Disciplina::getCodigo() const
{
    return codigo;
}

void Disciplina::setCodigo(const QString &newCodigo)
{
    codigo = newCodigo;
}

QString Disciplina::getNome() const
{
    return nome;
}

void Disciplina::setNome(const QString &newNome)
{
    nome = newNome;
}

QString Disciplina::toQString()const{
    return codigo + ";" + nome;
}
