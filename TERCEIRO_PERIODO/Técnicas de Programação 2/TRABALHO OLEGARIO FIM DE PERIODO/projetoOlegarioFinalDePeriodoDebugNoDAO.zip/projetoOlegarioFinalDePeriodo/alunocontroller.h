#ifndef ALUNOCONTROLLER_H
#define ALUNOCONTROLLER_H


#include <QString>
#include "aluno.h"
#include "alunodao.h"
#include <list>
class AlunoController
{
public:
    AlunoController();
    void incluir(QString const &mat, QString const &nome);
    QString buscar(QString const &mat);
    void alterar(QString const &mat, QString const &nome);
    void remover(QString const &mat);
    bool analisar(QString const &mat);
    QString listarAlunos(std::list<Aluno*> lista);
private:
    Aluno* aluno;
    AlunoDAO dao;
    std::list<const Aluno*> listaAlunos;
};


#endif // ALUNOCONTROLLER_H
