#ifndef TELAPRINCIPAL_H
#define TELAPRINCIPAL_H

#include <QMainWindow>

#include "alunocontroller.h"
#include "disicplinacontroller.h"
#include "matriculacontroller.h"
#include "turmacontroller.h"
#include <QMessageBox>
#include <QString>
#include <QMessageBox>
#include <QtSql>
QT_BEGIN_NAMESPACE
namespace Ui { class TelaPrincipal; }
QT_END_NAMESPACE

class TelaPrincipal : public QMainWindow
{
    Q_OBJECT

public:
    TelaPrincipal(QWidget *parent = nullptr);
    ~TelaPrincipal();

private:
    Ui::TelaPrincipal *ui;
    AlunoController controleAluno;
    DisicplinaController controleDisciplina;
        MatriculaController controleMatricula;
        TurmaController controleTurma;
};
#endif // TELAPRINCIPAL_H
