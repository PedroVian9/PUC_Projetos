#include "turmadao.h"

TurmaDAO::TurmaDAO()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    nomeBD = "/Users/olegariocorreadasilvaneto/SistAcad/academico.db";
    db.setDatabaseName(nomeBD);
}
void TurmaDAO::incluir(Turma* obj){
    if (!db.open()){
        throw QString("Erro ao abrir o banco de dados");
    }
    QSqlQuery query;
    query.prepare("INSERT INTO turma (cod_discip, cod_turma) VALUES (:cod_discip, :cod_turma;");
    query.bindValue(":cod_disciplina", obj->getDisciplina().getCodigo());
    query.bindValue(":cod_turma", obj->getCodigo());
    if (!query.exec()){
        db.close();
        throw QString("Erro ao executar a inserção");
    }
    db.close();
}

Turma *TurmaDAO::buscar(Turma *obj)
{
    if (!db.open()){
        throw QString("Erro ao abrir o banco de dados");
    }
    QString cod_discip(""), cod_turma("");
    QSqlQuery query;
    if (obj!=nullptr){
        query.prepare("SELECT * FROM turma WHERE cod_discip = :cod_discip, cod_turma = :cod_turma;");
        query.bindValue(":cod_discip", obj->getDisciplina().getCodigo());
        query.bindValue(":nome", obj->getCodigo());
        if (!query.exec()){
            db.close();
            throw QString("Erro ao executar a consulta");
        }
        while (query.next()){
            cod_discip = query.value(0).toString();
            cod_turma = query.value(1).toString();
        }
        obj->getDisciplina().setCodigo(cod_discip);
        obj->setCodigo(cod_turma);
        db.close();
    }
    if (obj!=nullptr)
        return obj;
    else{
        delete obj;
        return nullptr;
    }
}

void TurmaDAO::alterar(Turma *obj)
{
    Turma* turma = new Turma();
    turma->getDisciplina().setCodigo(obj->getDisciplina().getCodigo());
    turma->setCodigo(obj->getCodigo());
    if (this->buscar(turma)==nullptr){
        throw QString("Turma não encontrada!");
    }
    else{
        if (!db.open()){
            throw QString("Erro ao abrir o banco de dados");
        }
        QSqlQuery query;
        query.prepare("UPDATE turma SET cod_discip = :cod_discip WHERE cod_turma :cod_turma;");
        query.bindValue(":cod_discip", obj->getDisciplina().getCodigo());
        query.bindValue(":cod_turma", obj->getCodigo());
        if (!query.exec()){
            db.close();
            throw QString("Erro ao executar a update");
        }
        db.close();
        delete obj;
    }
}

Turma *TurmaDAO::remover(Turma *obj)
{
    Turma* turma = new Turma();
    turma->getDisciplina().setCodigo(obj->getDisciplina().getCodigo());
    turma->setCodigo(obj->getCodigo());
    if (this->buscar(turma)==nullptr){
        throw QString("Turma não encontrada!");
    }
    else{
        if (!db.open()){
            throw QString("Erro ao abrir o banco de dados");
        }
        QSqlQuery query;
        query.prepare("DELETE FROM turma WHERE cod_discip = :cod_discip, cod_turma :cod_turma;");
        query.bindValue(":cod_discip", obj->getDisciplina().getCodigo());
        query.bindValue(":cod_turma", obj->getCodigo());
        if (!query.exec()){
            db.close();
            throw QString("Erro ao executar a delete");
        }
        db.close();
        delete obj;
    }
}
