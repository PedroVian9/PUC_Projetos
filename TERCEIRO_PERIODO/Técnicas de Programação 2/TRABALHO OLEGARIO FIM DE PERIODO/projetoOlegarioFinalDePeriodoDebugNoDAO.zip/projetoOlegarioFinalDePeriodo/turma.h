#ifndef TURMA_H
#define TURMA_H
#include <QString>
#include "disciplina.h"

class Turma
{
public:
    Turma();
    Turma(Disciplina const &newDisciplina, QString cod);
    Turma(Disciplina const &newDisciplina, QString cod, QString sub);

    QString getCodigo() const;
    void setCodigo(const QString &newCodigo);

    QString getSubTurma() const;
    void setSubTurma(const QString &newSubTurma);

    int getNumMax() const;
    void setNumMax(int newNumMax);

    QString toQString()const;

    Disciplina getDisciplina() const;
    void setDisciplina(const Disciplina &newDisciplina);

    int getNumAlunos() const;
    void setNumAlunos(int newNumAlunos);

private:
    Disciplina disciplina;
    QString codigo;
    QString subTurma;
    int numMax;
    int numAlunos;
};

#endif // TURMA_H
