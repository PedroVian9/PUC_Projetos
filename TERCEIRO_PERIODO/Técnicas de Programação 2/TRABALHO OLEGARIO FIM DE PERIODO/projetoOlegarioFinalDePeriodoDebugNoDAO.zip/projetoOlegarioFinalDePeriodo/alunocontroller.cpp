#include "alunocontroller.h"

AlunoController::AlunoController()
{

}
void AlunoController::incluir(QString const &mat, QString const &nome){
    aluno = new Aluno(mat, nome);
    if(AlunoController::analisar(mat)==false){ throw QString("Aluno já consta no banco de dados!");}
    aluno->setMatricula(mat);
    aluno->setNome(nome);
    dao.incluir(aluno);
    listaAlunos.push_back(aluno);
    aluno = nullptr;
}

QString AlunoController::buscar(QString const &mat){
    aluno = nullptr;
    aluno = dao.buscar(new Aluno(mat, ""));
    if (aluno!=nullptr)
        return aluno->toQString();
    else
        throw QString("Aluno não encontrado!");
}

void AlunoController::alterar(QString const &mat, QString const &nome){
    dao.alterar(new Aluno(mat, nome));
}

void AlunoController::remover(QString const &mat){
    dao.remover(new Aluno(mat));
}

bool AlunoController::analisar(const QString &mat){
    aluno = nullptr;
    aluno = dao.buscar(new Aluno(mat, ""));
    if (aluno->getMatricula()!=nullptr){
        delete aluno;
        return true;
    }
    delete aluno;
    return false;
}

//QString AlunoController::listarAlunos(std::list<Aluno *> lista)
//{
//    QString saida="";
//    for(auto aluno = listaAlunos.begin(); aluno != listaAlunos.end(); aluno++)
//    {
//        saida += (*aluno)->getMatricula() + " " + (*aluno)->getNome();
//        saida += "\n";
//    }
//    return saida;
//}
