#ifndef DISCIPLINA_H
#define DISCIPLINA_H

#include <QString>

class Disciplina
{
public:
    Disciplina();
    Disciplina(QString cod);
    Disciplina(QString cod, QString nom);
    QString getCodigo() const;
    void setCodigo(const QString &newCodigo);

    QString getNome() const;
    void setNome(const QString &newNome);

    QString toQString()const;
private:
    QString codigo;
    QString nome;
};

#endif // DISCIPLINA_H
