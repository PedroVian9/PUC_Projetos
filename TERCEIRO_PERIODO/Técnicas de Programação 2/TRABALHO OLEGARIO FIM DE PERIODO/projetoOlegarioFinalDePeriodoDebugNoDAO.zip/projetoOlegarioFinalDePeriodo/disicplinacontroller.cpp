#include "disicplinacontroller.h"

DisicplinaController::DisicplinaController()
{

}
void DisicplinaController::incluir(QString const &cod, QString const &nome){
    disciplina = new Disciplina(cod, nome);
    if(DisicplinaController::analisar(cod)==false){ throw QString("Disciplina já consta no banco de dados!");}
    disciplina ->setCodigo(cod);
    disciplina ->setNome(nome);
    dao.incluir(disciplina);
    disciplina = nullptr;
}

QString DisicplinaController::buscar(QString const &cod){
    disciplina = nullptr;
    disciplina = dao.buscar(new Disciplina(cod));
    if (disciplina!=nullptr)
        return disciplina->toQString();
    else
        throw QString("Disciplina não encontrado!");
}

void DisicplinaController::alterar(const QString &cod, const QString &nome){
    dao.alterar(new Disciplina(cod, nome));
}

void DisicplinaController::remover(const QString &cod){
    dao.remover(new Disciplina(cod));
}

bool DisicplinaController::analisar(const QString &cod)
{
    disciplina = nullptr;
    disciplina = dao.buscar(new Disciplina(cod, ""));
    if (disciplina->getCodigo()!=nullptr){
        delete disciplina;
        return true;
    }
    delete disciplina;
    return false;
}
