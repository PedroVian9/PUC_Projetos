#include "turma.h"

Turma::Turma()
{

}
Turma::Turma(const Disciplina &newDisciplina, QString cod)
{
    disciplina = newDisciplina;
    codigo = cod;
}

Turma::Turma(const Disciplina &newDisciplina, QString cod, QString sub)
{
    disciplina = newDisciplina;
    codigo = cod;
    subTurma = sub;
}

QString Turma::getCodigo() const
{
    return codigo;
}

void Turma::setCodigo(const QString &newCodigo)
{
    codigo = newCodigo;
}

QString Turma::getSubTurma() const
{
    return subTurma;
}

void Turma::setSubTurma(const QString &newSubTurma)
{
    subTurma = newSubTurma;
}

int Turma::getNumMax() const
{
    return numMax;
}

void Turma::setNumMax(int newNumMax)
{
    numMax = newNumMax;
}

Disciplina Turma::getDisciplina() const
{
    return disciplina;
}

void Turma::setDisciplina(const Disciplina &newDisciplina)
{
    disciplina = newDisciplina;
}

int Turma::getNumAlunos() const
{
    return numAlunos;
}

void Turma::setNumAlunos(int newNumAlunos)
{
    numAlunos = newNumAlunos;
}

QString Turma::toQString()const{
    return disciplina.getCodigo() + "; " +
            codigo + ";" +
            subTurma + ";";
}
