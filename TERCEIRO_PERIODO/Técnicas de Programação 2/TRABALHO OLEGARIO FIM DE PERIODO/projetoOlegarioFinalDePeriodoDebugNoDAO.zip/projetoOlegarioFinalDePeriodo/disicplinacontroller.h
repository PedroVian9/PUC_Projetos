#ifndef DISICPLINACONTROLLER_H
#define DISICPLINACONTROLLER_H
#include <QString>
#include <disciplina.h>
#include "disciplinadao.h"

class DisicplinaController
{
public:
    DisicplinaController();
    void incluir(QString const &cod, QString const &nome);
    QString buscar(QString const &cod);
    void alterar(QString const &cod, QString const &nome);
    void remover(QString const &cod);
    bool analisar(QString const &cod);
private:
    Disciplina* disciplina;
    DisciplinaDAO dao;
};

#endif // DISICPLINACONTROLLER_H
