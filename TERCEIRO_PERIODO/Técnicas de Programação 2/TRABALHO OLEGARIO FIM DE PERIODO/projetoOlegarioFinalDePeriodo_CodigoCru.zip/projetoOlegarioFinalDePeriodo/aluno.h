#ifndef ALUNO_H
#define ALUNO_H


class Aluno
{
public:
    Aluno();
};

#endif // ALUNO_H
