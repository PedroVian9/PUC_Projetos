#ifndef TURMA_H
#define TURMA_H


class Turma
{
public:
    Turma();
};

#endif // TURMA_H
