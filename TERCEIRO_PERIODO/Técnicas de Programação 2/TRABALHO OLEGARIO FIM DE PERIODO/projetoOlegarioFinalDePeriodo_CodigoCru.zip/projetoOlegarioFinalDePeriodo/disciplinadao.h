#ifndef DISCIPLINADAO_H
#define DISCIPLINADAO_H


class DisciplinaDAO
{
public:
    DisciplinaDAO();
};

#endif // DISCIPLINADAO_H
