#include "matriculacontroller.h"

MatriculaController::MatriculaController()
{

}
