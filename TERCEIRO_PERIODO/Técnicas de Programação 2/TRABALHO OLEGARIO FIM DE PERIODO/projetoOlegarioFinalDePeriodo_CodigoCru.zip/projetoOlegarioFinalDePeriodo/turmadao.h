#ifndef TURMADAO_H
#define TURMADAO_H


class TurmaDAO
{
public:
    TurmaDAO();
};

#endif // TURMADAO_H
