#include "matricula.h"

Matricula::Matricula()
{

}
