#include "disciplina.h"

Disciplina::Disciplina()
{

}
