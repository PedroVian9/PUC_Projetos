#ifndef DAO_H
#define DAO_H


class DAO
{
public:
    DAO();
};

#endif // DAO_H
