#ifndef TURMACONTROLLER_H
#define TURMACONTROLLER_H


class TurmaController
{
public:
    TurmaController();
};

#endif // TURMACONTROLLER_H
