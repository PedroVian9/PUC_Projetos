#ifndef ALUNOCONTROLLER_H
#define ALUNOCONTROLLER_H


class AlunoController
{
public:
    AlunoController();
};

#endif // ALUNOCONTROLLER_H
