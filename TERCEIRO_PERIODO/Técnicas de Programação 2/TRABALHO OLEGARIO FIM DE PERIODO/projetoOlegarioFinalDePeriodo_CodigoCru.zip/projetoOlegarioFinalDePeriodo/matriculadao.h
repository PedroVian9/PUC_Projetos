#ifndef MATRICULADAO_H
#define MATRICULADAO_H


class MatriculaDAO
{
public:
    MatriculaDAO();
};

#endif // MATRICULADAO_H
