#ifndef MATRICULACONTROLLER_H
#define MATRICULACONTROLLER_H


class MatriculaController
{
public:
    MatriculaController();
};

#endif // MATRICULACONTROLLER_H
