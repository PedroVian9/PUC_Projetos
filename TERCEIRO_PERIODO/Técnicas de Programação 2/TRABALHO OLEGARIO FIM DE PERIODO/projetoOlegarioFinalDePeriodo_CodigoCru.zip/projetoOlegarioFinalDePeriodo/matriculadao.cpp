#include "matriculadao.h"

MatriculaDAO::MatriculaDAO()
{

}
