#include "disicplinacontroller.h"

DisicplinaController::DisicplinaController()
{

}
