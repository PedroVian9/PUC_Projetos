#ifndef DISICPLINACONTROLLER_H
#define DISICPLINACONTROLLER_H


class DisicplinaController
{
public:
    DisicplinaController();
};

#endif // DISICPLINACONTROLLER_H
