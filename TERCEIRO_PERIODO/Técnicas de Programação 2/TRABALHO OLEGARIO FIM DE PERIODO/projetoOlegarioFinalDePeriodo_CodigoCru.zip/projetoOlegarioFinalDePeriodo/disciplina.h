#ifndef DISCIPLINA_H
#define DISCIPLINA_H


class Disciplina
{
public:
    Disciplina();
};

#endif // DISCIPLINA_H
