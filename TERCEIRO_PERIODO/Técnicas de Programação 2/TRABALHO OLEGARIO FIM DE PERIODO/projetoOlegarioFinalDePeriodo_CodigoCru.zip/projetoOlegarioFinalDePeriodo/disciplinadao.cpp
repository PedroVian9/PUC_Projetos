#include "disciplinadao.h"

DisciplinaDAO::DisciplinaDAO()
{

}
