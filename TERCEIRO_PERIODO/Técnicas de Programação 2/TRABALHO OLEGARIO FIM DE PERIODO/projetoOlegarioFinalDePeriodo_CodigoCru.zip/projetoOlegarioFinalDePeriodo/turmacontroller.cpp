#include "turmacontroller.h"

TurmaController::TurmaController()
{

}
