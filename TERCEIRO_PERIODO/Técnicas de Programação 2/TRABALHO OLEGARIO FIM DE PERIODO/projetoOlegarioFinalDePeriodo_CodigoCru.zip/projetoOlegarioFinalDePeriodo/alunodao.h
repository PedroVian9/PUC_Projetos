#ifndef ALUNODAO_H
#define ALUNODAO_H


class AlunoDAO
{
public:
    AlunoDAO();
};

#endif // ALUNODAO_H
