#ifndef MATRICULA_H
#define MATRICULA_H


class Matricula
{
public:
    Matricula();
};

#endif // MATRICULA_H
