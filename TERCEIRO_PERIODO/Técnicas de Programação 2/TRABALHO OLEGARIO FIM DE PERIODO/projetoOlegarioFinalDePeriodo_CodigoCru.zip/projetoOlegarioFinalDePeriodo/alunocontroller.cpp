#include "alunocontroller.h"

AlunoController::AlunoController()
{

}
