#ifndef ALUNO_H
#define ALUNO_H
#include <QString>

class Aluno
{
public:
    Aluno();
    QString matricula;
    QString nome;
    const QString &getMatricula() const;
    void setMatricula(const QString &newMatricula);
    const QString &getNome() const;
    void setNome(const QString &newNome);
};

#endif // ALUNO_H
