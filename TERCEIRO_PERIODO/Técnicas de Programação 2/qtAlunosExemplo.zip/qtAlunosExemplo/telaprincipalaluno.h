#ifndef TELAPRINCIPALALUNO_H
#define TELAPRINCIPALALUNO_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class TelaPrincipalAluno; }
QT_END_NAMESPACE

class TelaPrincipalAluno : public QMainWindow
{
    Q_OBJECT

public:
    TelaPrincipalAluno(QWidget *parent = nullptr);
    ~TelaPrincipalAluno();

private:
    Ui::TelaPrincipalAluno *ui;
};
#endif // TELAPRINCIPALALUNO_H
