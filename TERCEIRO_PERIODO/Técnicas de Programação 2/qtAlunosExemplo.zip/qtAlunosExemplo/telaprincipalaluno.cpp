#include "telaprincipalaluno.h"
#include "ui_telaprincipalaluno.h"

TelaPrincipalAluno::TelaPrincipalAluno(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TelaPrincipalAluno)
{
    ui->setupUi(this);
}

TelaPrincipalAluno::~TelaPrincipalAluno()
{
    delete ui;
}

