#ifndef ALUNODAO_H
#define ALUNODAO_H

#include "dao.h"
#include "aluno.h"

class AlunoDAO : public DAO<Aluno>
{
public:
    AlunoDAO();
};

#endif // ALUNODAO_H
