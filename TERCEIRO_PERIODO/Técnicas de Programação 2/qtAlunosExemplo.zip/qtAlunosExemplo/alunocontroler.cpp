#include "alunocontroler.h"

AlunoControler::AlunoControler()
{

}
