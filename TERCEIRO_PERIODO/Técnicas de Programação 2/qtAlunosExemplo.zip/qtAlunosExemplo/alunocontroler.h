#ifndef ALUNOCONTROLER_H
#define ALUNOCONTROLER_H


class AlunoControler
{
public:
    AlunoControler();
};

#endif // ALUNOCONTROLER_H
