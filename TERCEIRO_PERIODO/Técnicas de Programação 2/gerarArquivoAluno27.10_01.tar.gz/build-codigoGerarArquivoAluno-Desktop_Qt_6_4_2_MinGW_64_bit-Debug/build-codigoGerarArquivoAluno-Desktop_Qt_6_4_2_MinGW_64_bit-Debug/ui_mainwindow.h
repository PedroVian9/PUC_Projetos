/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label_5;
    QWidget *widget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEditMostrarArquivo;
    QPushButton *pushButtonBuscarArquivo;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QTextEdit *textEditApresentarOConteudoDoArquivo;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButtonGerarAluno;
    QPushButton *pushButtonGerarDisciplina;
    QPushButton *pushButtonGerarMatricula;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(764, 474);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(170, 30, 431, 41));
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(80, 80, 601, 334));
        verticalLayout_3 = new QVBoxLayout(widget);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        label = new QLabel(widget);
        label->setObjectName("label");

        horizontalLayout->addWidget(label);

        lineEditMostrarArquivo = new QLineEdit(widget);
        lineEditMostrarArquivo->setObjectName("lineEditMostrarArquivo");
        lineEditMostrarArquivo->setReadOnly(true);

        horizontalLayout->addWidget(lineEditMostrarArquivo);

        pushButtonBuscarArquivo = new QPushButton(widget);
        pushButtonBuscarArquivo->setObjectName("pushButtonBuscarArquivo");

        horizontalLayout->addWidget(pushButtonBuscarArquivo);


        verticalLayout_3->addLayout(horizontalLayout);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        label_2 = new QLabel(widget);
        label_2->setObjectName("label_2");

        verticalLayout->addWidget(label_2);

        textEditApresentarOConteudoDoArquivo = new QTextEdit(widget);
        textEditApresentarOConteudoDoArquivo->setObjectName("textEditApresentarOConteudoDoArquivo");

        verticalLayout->addWidget(textEditApresentarOConteudoDoArquivo);


        verticalLayout_3->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        label_4 = new QLabel(widget);
        label_4->setObjectName("label_4");

        verticalLayout_2->addWidget(label_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        pushButtonGerarAluno = new QPushButton(widget);
        pushButtonGerarAluno->setObjectName("pushButtonGerarAluno");

        horizontalLayout_2->addWidget(pushButtonGerarAluno);

        pushButtonGerarDisciplina = new QPushButton(widget);
        pushButtonGerarDisciplina->setObjectName("pushButtonGerarDisciplina");

        horizontalLayout_2->addWidget(pushButtonGerarDisciplina);

        pushButtonGerarMatricula = new QPushButton(widget);
        pushButtonGerarMatricula->setObjectName("pushButtonGerarMatricula");

        horizontalLayout_2->addWidget(pushButtonGerarMatricula);


        verticalLayout_2->addLayout(horizontalLayout_2);


        verticalLayout_3->addLayout(verticalLayout_2);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 764, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:700; font-style:italic; text-decoration: underline;\">MANIPULA\303\207\303\203O DE ARQUIVO CSV</span></p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">ARQUIVO:</span></p></body></html>", nullptr));
        pushButtonBuscarArquivo->setText(QCoreApplication::translate("MainWindow", "BUSCAR ", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">APRESENTA\303\207\303\203O:</span></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700;\">GERAR ARQUIVO .CSV</span></p></body></html>", nullptr));
        pushButtonGerarAluno->setText(QCoreApplication::translate("MainWindow", "ALUNO", nullptr));
        pushButtonGerarDisciplina->setText(QCoreApplication::translate("MainWindow", "DISCIPLINA", nullptr));
        pushButtonGerarMatricula->setText(QCoreApplication::translate("MainWindow", "MATR\303\215CULA", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
