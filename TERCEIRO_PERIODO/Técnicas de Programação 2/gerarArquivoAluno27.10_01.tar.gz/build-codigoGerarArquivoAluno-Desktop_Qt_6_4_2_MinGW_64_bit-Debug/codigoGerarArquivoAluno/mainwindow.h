#ifndef MAINWINDOW_H
#define MAINWINDOW_H

//Biblioteca de manipulação dos diretorios do disco
#include <QFileDialog>
#include <QString>
#include <QMessageBox>
//Biblioteca para tratamento de arquivos
#include<fstream>


#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButtonBuscarArquivo_clicked();

    void on_pushButtonGerarAluno_clicked();

    void on_pushButtonGerarDisciplina_clicked();

    void on_pushButtonGerarMatricula_clicked();

private:
    Ui::MainWindow *ui;
    QString arquivoCsv = "";
};
#endif // MAINWINDOW_H
