#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <fstream>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButtonBuscarArquivo_clicked()
{
    try {
            // nomeDoArquivo - atributo da classe MainWindow
            //Buscando o arquivo no disco
            arquivoCsv = QFileDialog::getOpenFileName(this,"Abrir Arquivo",QDir::currentPath(),"Arquivos Textos (*.csv *.txt *.*)");
            if(arquivoCsv.isEmpty()) throw QString("Arquivo nao foi selecionado");
            ui->lineEditMostrarArquivo->setText(arquivoCsv);
        } catch (QString &erro) {
            QMessageBox::information(this,"ERRO",erro);
        }
    // criando um arquivo de entrada
    std::ifstream arquivo;

    // abrindo um arquivo de entrada
    arquivo.open(arquivoCsv.toStdString().c_str());

    // verificando erro de abertura do arquivo de entrada
    if(!arquivo.is_open()){
        throw QString("ERRO Arquivo nao pode ser aberto");
    }

    std::string linha;
    QString texto;

    // lendo do arquivo
    getline(arquivo,linha);

    // Teste de fim do arquivo
    while(!arquivo.eof()){

        texto += QString::fromStdString(linha);
        texto += "\n";
        //lendo do arquivo
        getline(arquivo,linha);
    }
    // fechado o arquivo de entrada
    arquivo.close();

    ui->textEditApresentarOConteudoDoArquivo->setText(texto);

}

void MainWindow::on_pushButtonGerarAluno_clicked()
{





}


void MainWindow::on_pushButtonGerarDisciplina_clicked()
{

}


void MainWindow::on_pushButtonGerarMatricula_clicked()
{

}

