#include <iostream>

const int linhas=3, colunas=3;
void lermatriz(int matriz[linhas][colunas],std::string str)
{
    for(int i=0; i<linhas; i++)
    {
        for(int j=0; j<colunas; j++)
        {
            std::cout<<"matriz["<<i<<"]["<<j<<"]= ";
            std::cin>>matriz[i][j];
        }
    }
    std::cout<<"\n";
}

int main()
{
    const int linhas=3 ,colunas=3;
    int matrizA[linhas][colunas];
    int matrizB[linhas][colunas];
    int matrizC[linhas][colunas];
    for(int i=0; i<linhas; i++)
    {
        for(int j=0; j<colunas; j++)
        {
           matrizC[i][j]=0;
        }
    }
    lermatriz(matrizA,"A");
    lermatriz(matrizB,"B");
    int escolha=0;

    do
    {
        std::cout<<"MENU DE OPÇÕES";
        std::cout<<"\n1 - Adição de matrizes";
        std::cout<<"\n2 - Subtração de matrizes";
        std::cout<<"\n3 - Multiplicação de matrizes";
        std::cout<<"\n4 - Verificar triangularidade superior das matrizes";
        std::cout<<"\n5 - Verificar triangularidade inferior das matrizes";
        std::cout<<"\n6 - Verificar se as matrizes são simétricas";
        std::cout<<"\n7 - Verificar se as matrizes são anti-simétricas";
        std::cout<<"\n8 - Verificar se as duas matrizes são iguais";
        std::cout<<"\n9 - Sair do programa";
        std::cout<<"\nDigite o número correspondente da opção desejada: \n";
        std::cin>>escolha;

    switch(escolha)
    {
        case 1:
        {
        for(int i=0;i<linhas;i++)
        {
            for(int j=0;j<colunas;j++)
            {
                std::cout<<matrizA[i][j]+matrizB[i][j]<<" ";
            }
            std::cout<<"\n";
            }
        }
        break;

        case 2:
        {
            for(int i=0;i<linhas;i++)
            {
                for(int j=0;j<colunas;j++)
                {
                    std::cout<<matrizA[i][j]-matrizB[i][j]<<" ";
                }
                std::cout<<"\n";
                }
        }
        break;

        case 3:
        {

            for(int i=0; i<linhas; i++)
            {
                for(int j=0; j<colunas; j++)
                {
                    for(int k=0; k<colunas; k++)
                    {
                        matrizC[i][j] = matrizC[i][j] + matrizA[i][k] * matrizB [k][j];
                    }
                }
            }
            for(int i=0; i<linhas; i++)
            {
                for(int j=0; j<colunas; j++)
                {
                    std::cout<<matrizC[i][j]<<" ";
                }
                std::cout<<"\n"<<std::endl;
            }
        }
        break;

        case 4:
        {
        int ia,ja,ib,jb,x=1;
        for(ia=linhas; ia>1; ia--)
        {
            for(ja=0; ja<colunas-x && matrizA[ia][ja] == 0; ja++ && x++);
        }
        for(ib=linhas; ib>1; ib--)
        {
            for(jb=0; jb<colunas-x && matrizB[ib][jb] == 0; jb++ && x++);
        }
        if(ja==colunas-x && jb==colunas-x)
        {std::cout<<"As matrizes são triangulares superiores\n";}
        else
        {
            if(ja<colunas-x && jb==colunas-x)
            {std::cout<<"Apenas a matriz B é triangular superior\n";}
            else
            {
                if(ja==colunas-x && jb<colunas-x)
                {std::cout<<"Apenas a matriz A é triangular superior\n";}
                else
                {
                    if(ja<colunas-x && jb<colunas-x)
                    {std::cout<<"As matrizes não são triangulares superiores\n";}
                }
            }
        }
        }
        break;

        case 5:
        {
            int ia,ja,ib,jb;
            for(ia=0; ia<linhas-1; ia++)
            {
                for(ja=1+ia; ja<colunas && matrizA[ia][ja] == 0; ja++);
            }
            for(ib=0; ib<linhas-1; ib++)
            {
                for(jb=1+ib; jb<colunas && matrizB[ib][jb] == 0; jb++);
            }
            if(ja==colunas && jb==colunas)
            {std::cout<<"As matrizes são triangulares inferiores\n";}
            else
            {
                if(ja<colunas && jb==colunas)
                {std::cout<<"Apenas a matriz B é triangular inferior\n";}
                else
                {
                    if(ja==colunas && jb<colunas)
                    {std::cout<<"Apenas a matriz A é triangular inferior\n";}
                    else
                    {
                        if(ja<colunas && jb<colunas)
                        {std::cout<<"As matrizes não são triangulares inferiores\n";}
                    }
                }
            }
        }
        break;

        case 8:
        {
            int i,j;
            for(i=0; i<linhas && matrizA[i][j] == matrizB[i][j]; i++)
            {
                for(j=0; j<colunas && matrizA[i][j] == matrizB[i][j]; j++);
            }
            if(j==colunas)
            {std::cout<<"\nAs matrizes são iguais\n"<<std::endl;}
            else
            {std::cout<<"\nAs matrizes não são iguais\n"<<std::endl;}
        }
        break;
    }
    }
    while(escolha!=9);
}



